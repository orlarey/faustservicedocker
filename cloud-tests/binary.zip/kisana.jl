const FAUSTFLOAT = Float32
# ************************************************************************
# FAUST Architecture File
# Copyright (C) 2021 GRAME, Centre National de Creation Musicale
# ---------------------------------------------------------------------

# This is sample code. This file is provided as an example of minimal
# FAUST architecture file. Redistribution and use in source and binary
# forms, with or without modification, in part or in full are permitted.
# In particular you can create a derived work of this FAUST architecture
# and distribute that work under terms of your choice.

# This sample code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# ************************************************************************

# UI
abstract type UI end

# DSP
abstract type dsp end

function getSampleRate(dsp::dsp)
end

function getNumInputs(dsp::dsp)
end

function getNumOutputs(dsp::dsp)
end

function classInit!(sample_rate::Int32)
end

function instanceResetUserInterface!(dsp::dsp)
end

function instanceClear!(dsp::dsp)
end

function instanceInit!(dsp::dsp, sample_rate::Int32)
end

function init!(dsp::dsp, sample_rate::Int32)
end

function getJSON(dsp::dsp)
end

function buildUserInterface!(dsp::dsp, ui_interface::UI)
end

function compute!(dsp::dsp, count::Int32, inputs, outputs)
end
# ************************************************************************
# FAUST Architecture File
# Copyright (C) 2021 GRAME, Centre National de Creation Musicale
# ---------------------------------------------------------------------

# This is sample code. This file is provided as an example of minimal
# FAUST architecture file. Redistribution and use in source and binary
# forms, with or without modification, in part or in full are permitted.
# In particular you can create a derived work of this FAUST architecture
# and distribute that work under terms of your choice.

# This sample code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# ************************************************************************

# Architectures are conditionally included (since they may be already inlined in the file)
try 
    include("/usr/local/share/faust/julia/dsp/dsp.jl")
catch
end

abstract type audio end

function init(driver::audio, name::String, dsp::dsp)
end

# Blocking version
function run(driver::audio)
end

#=
function start(driver::audio)
end

function stop(driver::audio)
end
=## ************************************************************************
# FAUST Architecture File
# Copyright (C) 2021 GRAME, Centre National de Creation Musicale
# ---------------------------------------------------------------------

# This is sample code. This file is provided as an example of minimal
# FAUST architecture file. Redistribution and use in source and binary
# forms, with or without modification, in part or in full are permitted.
# In particular you can create a derived work of this FAUST architecture
# and distribute that work under terms of your choice.

# This sample code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# ************************************************************************

# Architectures are conditionally included (since they may be already inlined in the file)
try 
    include("/usr/local/share/faust/julia/audio/audio.jl")
catch 
end

# Using PortAudio for audio rendering
using PortAudio

mutable struct portaudio <: audio
    portaudio(buffer_size::Int, sample_rate::Int) = begin
        driver = new()
        driver.buffer_size = buffer_size
        driver.sample_rate = sample_rate
        driver
    end 
    dsp::dsp
    buffer_size::Int
    sample_rate::Int
    name::String        
end

function init!(driver::portaudio, name::String, dsp::dsp)
    driver.name = name
    driver.dsp = dsp
    init!(dsp, Int32(driver.sample_rate))
end

function run(driver::portaudio)
    PortAudioStream(1, 2) do stream
        outputs = zeros(FAUSTFLOAT, driver.buffer_size, getNumOutputs(driver.dsp))
        while true
            inputs = convert(Matrix{FAUSTFLOAT}, read(stream, driver.buffer_size))
            compute!(driver.dsp, Int32(driver.buffer_size), inputs, outputs)
            write(stream, outputs)
        end
    end
end
# ************************************************************************
# FAUST Architecture File
# Copyright (C) 2021 GRAME, Centre National de Creation Musicale
# ---------------------------------------------------------------------

# This is sample code. This file is provided as an example of minimal
# FAUST architecture file. Redistribution and use in source and binary
# forms, with or without modification, in part or in full are permitted.
# In particular you can create a derived work of this FAUST architecture
# and distribute that work under terms of your choice.

# This sample code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# ************************************************************************

# The base class of Meta handler to be used in metadata(dsp::dsp, m::Meta) method to retrieve (key, value) metadata.

abstract type Meta end

function declare!(m::Meta, key::String, value::String)
end
# ************************************************************************
# FAUST Architecture File
# Copyright (C) 2021 GRAME, Centre National de Creation Musicale
# ---------------------------------------------------------------------

# This is sample code. This file is provided as an example of minimal
# FAUST architecture file. Redistribution and use in source and binary
# forms, with or without modification, in part or in full are permitted.
# In particular you can create a derived work of this FAUST architecture
# and distribute that work under terms of your choice.

# This sample code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# ************************************************************************

# UI architecture
abstract type UI end

# One can override the behavior by defining another set of methods 
# that takes a different concrete UI type. 
# Only the needed methods have to be implemented in subtypes.

# -- widget's layouts
function openTabBox!(ui_interface::UI, label::String)
end
function openHorizontalBox!(ui_interface::UI, label::String)
end
function openVerticalBox!(ui_interface::UI, label::String)
end
function closeBox!(ui_interface::UI)
end

# -- active widgets
function addButton!(ui_interface::UI, label::String, param::Symbol) 
end
function addCheckButton!(ui_interface::UI, label::String, param::Symbol) 
end
function addHorizontalSlider!(ui_interface::UI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
end
function addVerticalSlider!(ui_interface::UI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
end
function addNumEntry!(ui_interface::UI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
end

# -- passive widgets
function addHorizontalBargraph!(ui_interface::UI, label::String, param::Symbol, min::FAUSTFLOAT, max::FAUSTFLOAT)
end
function addVerticalBargraph!(ui_interface::UI, label::String, param::Symbol, min::FAUSTFLOAT, max::FAUSTFLOAT)
end

# -- soundfiles
function addSoundfile!(ui_interface::UI, label::String, filename::String, soundfile::Symbol) 
end

# -- metadata declarations
function declare!(ui_interface::UI, param::Symbol, key::String, val::String) 
end
# ************************************************************************
# FAUST Architecture File
# Copyright (C) 2021 GRAME, Centre National de Creation Musicale
# ---------------------------------------------------------------------

# This is sample code. This file is provided as an example of minimal
# FAUST architecture file. Redistribution and use in source and binary
# forms, with or without modification, in part or in full are permitted.
# In particular you can create a derived work of this FAUST architecture
# and distribute that work under terms of your choice.

# This sample code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# ************************************************************************

# Architectures are conditionnaly included (since they may be already inlined in the file)
try 
    include("/usr/local/share/faust/julia/dsp/dsp.jl")
    include("/usr/local/share/faust/julia/gui/UI.jl")
catch 
end

# PathBuilder 
mutable struct PathBuilder
    controlsLevel::Array{String}
end

function pushLabel!(builder::PathBuilder, label::String)
    push!(builder.controlsLevel, label)
end

function popLabel!(builder::PathBuilder)
    deleteat!(builder.controlsLevel, lastindex(builder.controlsLevel))
end

function buildPath(builder::PathBuilder, label::String)
    path = join(builder.controlsLevel, "/")
    res = "/$path/$label"
    for c in [' ', '#', '*', ',', '?', '[', ']', '{', '}', '(', ')'] 
        res = replace(res, c => '_')
    end
    res
end

# UIZone with for sliders, nentries and bargraph
struct UIZone
    field::Symbol
    init::Float32
    min::Float32
    max::Float32
    step::Float32
end

# MapUI to keep [path,Symbol] and [label,Symbol] maps
mutable struct MapUI <: UI
    MapUI(dsp::dsp) = begin
        map_ui = new()
        map_ui.dsp = dsp
        map_ui.label_paths = Dict{String,UIZone}()
        map_ui.osc_paths = Dict{String,UIZone}()
        map_ui.path_builder = PathBuilder([])
        map_ui.root = String("") 
        map_ui
	end
    dsp::dsp
    path_builder::PathBuilder
    label_paths::Dict{String,UIZone}
    osc_paths::Dict{String,UIZone}
    root::String
end

# -- widget's layouts
function openTabBox!(ui_interface::MapUI, label::String)
    if (ui_interface.root == "") ui_interface.root = label end
    pushLabel!(ui_interface.path_builder, label)
end
function openHorizontalBox!(ui_interface::MapUI, label::String)
    if (ui_interface.root == "") ui_interface.root = label end
    pushLabel!(ui_interface.path_builder, label)
end
function openVerticalBox!(ui_interface::MapUI, label::String)
    if (ui_interface.root == "") ui_interface.root = label end
    pushLabel!(ui_interface.path_builder, label)
end
function closeBox!(ui_interface::MapUI)
    popLabel!(ui_interface.path_builder)
end

# -- active widgets
function addButton!(ui_interface::MapUI, label::String, param::Symbol) 
    zone = UIZone(param, 0, 0, 1, 0)
    ui_interface.label_paths[label] = zone
    ui_interface.osc_paths[buildPath(ui_interface.path_builder, label)] = zone
end
function addCheckButton!(ui_interface::MapUI, label::String, param::Symbol) 
    zone = UIZone(param, 0, 0, 1, 0)
    ui_interface.label_paths[label] = zone
    ui_interface.osc_paths[buildPath(ui_interface.path_builder, label)] = zone
end
function addHorizontalSlider!(ui_interface::MapUI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
    zone = UIZone(param, init, min, max, step)
    ui_interface.label_paths[label] = zone
    ui_interface.osc_paths[buildPath(ui_interface.path_builder, label)] = zone
end
function addVerticalSlider!(ui_interface::MapUI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
    zone = UIZone(param, init, min, max, step)
    ui_interface.label_paths[label] = zone
    ui_interface.osc_paths[buildPath(ui_interface.path_builder, label)] = zone
end
function addNumEntry!(ui_interface::MapUI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
    zone = UIZone(param, init, min, max, step)
    ui_interface.label_paths[label] = zone
    ui_interface.osc_paths[buildPath(ui_interface.path_builder, label)] = zone
end

# -- passive widgets
function addHorizontalBargraph!(ui_interface::MapUI, label::String, param::Symbol, min::FAUSTFLOAT, max::FAUSTFLOAT)
    zone = UIZone(param, 0, min, max, 0)
    ui_interface.label_paths[label] = zone
    ui_interface.osc_paths[buildPath(ui_interface.path_builder, label)] = zone
end
function addVerticalBargraph!(ui_interface::MapUI, label::String, param::Symbol, min::FAUSTFLOAT, max::FAUSTFLOAT)
    zone = UIZone(param, 0, min, max, 0)
    ui_interface.label_paths[label] = zone
    ui_interface.osc_paths[buildPath(ui_interface.path_builder, label)] = zone
end

# setParamValue/getParamValue
function setParamValue!(ui_interface::MapUI, path::String, value::FAUSTFLOAT)
    if (haskey(ui_interface.osc_paths, path))
        setproperty!(ui_interface.dsp, ui_interface.osc_paths[path].field, value)
    elseif (haskey(ui_interface.label_paths, path))
        setproperty!(ui_interface.dsp, ui_interface.label_paths[path].field, value)
    else 
        println("ERROR : setParamValue '", path, "' not found")
    end
end

function getParamValue(ui_interface::MapUI, path::String)
    if (haskey(ui_interface.osc_paths, path))
        return getproperty(ui_interface.dsp, ui_interface.osc_paths[path].field)
    elseif (haskey(ui_interface.label_paths, path))
        return getproperty(ui_interface.dsp, ui_interface.label_paths[path].field)
    else 
        println("ERROR : getParamValue '", path, "' not found")
        return 0;
    end
end

function getZoneMap(ui_interface::MapUI)
    return ui_interface.osc_paths
end

function getRoot(ui_interface::MapUI)
    return "/" * ui_interface.root
end# ************************************************************************
# FAUST Architecture File
# Copyright (C) 2021 GRAME, Centre National de Creation Musicale
# ---------------------------------------------------------------------

# This is sample code. This file is provided as an example of minimal
# FAUST architecture file. Redistribution and use in source and binary
# forms, with or without modification, in part or in full are permitted.
# In particular you can create a derived work of this FAUST architecture
# and distribute that work under terms of your choice.

# This sample code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# ************************************************************************

# Architectures are conditionally included (since they may be already inlined in the file)
try 
    include("/usr/local/share/faust/julia/dsp/dsp.jl")
    include("/usr/local/share/faust/julia/gui/UI.jl")
catch 
end

using Gtk, GtkObservables

# GTKUI: a basic GUI developed using the GtkObservables package
mutable struct GTKUI <: UI
    GTKUI(dsp::dsp) = begin
        gtk_ui = new()
        gtk_ui.dsp = dsp
        gtk_ui.box = GtkBox(:v)
        gtk_ui.window = GtkWindow("Faust Program", 400, 200) |> gtk_ui.box
        gtk_ui
	end
    dsp::dsp
    window
    box
end

function run(ui_interface::GTKUI)
    showall(ui_interface.window)

    #= 
    if !isinteractive()
        @async Gtk.gtk_main()
        Gtk.waitforsignal(ui_interface.window, :destroy)
    end =#

    if !isinteractive()
        c = Condition()
        signal_connect(ui_interface.window, :destroy) do widget
            notify(c)
        end
        @async Gtk.gtk_main()
        wait(c)
    end
end

# -- active widgets
function addButton!(ui_interface::GTKUI, label::String, param::Symbol) 
    button = GtkObservables.button(label)
    obs_func = on(observable(button)) do val
        setproperty!(ui_interface.dsp, param, FAUSTFLOAT(1.0))
        # Hack to make it work...
        sleep(0.1)
        setproperty!(ui_interface.dsp, param, FAUSTFLOAT(0.0))
    end
    push!(ui_interface.box, button)
end

function addCheckButton!(ui_interface::GTKUI, label::String, param::Symbol) 
    checkbox = GtkObservables.checkbox()
    obs_func = on(observable(checkbox)) do val
        setproperty!(ui_interface.dsp, param, FAUSTFLOAT(val))
    end
    push!(ui_interface.box, checkbox)
end

function addHorizontalSlider!(ui_interface::GTKUI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
    slider = GtkObservables.slider(min:max, value=init, orientation="horizontal")
    obs_func = on(observable(slider)) do val
        setproperty!(ui_interface.dsp, param, val)
    end
    push!(ui_interface.box, slider)
end

function addVerticalSlider!(ui_interface::GTKUI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
    # slider = GtkObservables.slider(min:max, value=init, orientation="vertical") does not work...
    slider = GtkObservables.slider(min:max, value=init, orientation="horizontal")
    obs_func = on(observable(slider)) do val
        setproperty!(ui_interface.dsp, param, val)
    end
    push!(ui_interface.box, slider)
end

function addNumEntry!(ui_interface::GTKUI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
    nentry = GtkObservables.textbox(FAUSTFLOAT; range=min:max, value=string(init))
    obs_func = on(observable(nentry)) do val
        setproperty!(ui_interface.dsp, param, val)
    end
    push!(ui_interface.box, nentry)
end
# ************************************************************************
# FAUST Architecture File
# Copyright (C) 2021 GRAME, Centre National de Creation Musicale
# ---------------------------------------------------------------------

# This is sample code. This file is provided as an example of minimal
# FAUST architecture file. Redistribution and use in source and binary
# forms, with or without modification, in part or in full are permitted.
# In particular you can create a derived work of this FAUST architecture
# and distribute that work under terms of your choice.

# This sample code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# ************************************************************************

# Architectures are conditionnaly included (since they may be already inlined in the file)
try 
    include("/usr/local/share/faust/julia/dsp/dsp.jl")
    include("/usr/local/share/faust/julia/gui/MapUI.jl")
    include("/usr/local/share/faust/julia/gui/meta.jl")
catch 
end

using OpenSoundControl, Sockets, MacroTools

# Retrieve the application name
mutable struct NameMeta <: Meta
    name::String
end

function declare!(m::NameMeta, key::String, value::String)
    if (key == "name") 
        m.name = value;
        for c in [' ', '#', '*', ',', '?', '[', ']', '{', '}', '(', ')'] 
            m.name = replace(m.name, c => '_')
        end
        m.name = "/" * m.name
    end
end

# OSCUI: a GUI using the Open Sound Control (OSC) protocol to control parameters
mutable struct OSCUI <: UI
    OSCUI(dsp::dsp, inport::Int=5000, outport::Int=5001) = begin
        osc_ui = new()
        osc_ui.dsp = dsp
        osc_ui.map_ui = MapUI(dsp)
        osc_ui.rcv_socket = UDPSocket()
        bind(osc_ui.rcv_socket, ip"127.0.0.1", inport)
        osc_ui.snd_socket = UDPSocket()
        osc_ui.inport = inport
        osc_ui.outport = outport
        # Get root name, without the first '/'
        tmp_map_ui = MapUI(dsp)
        buildUserInterface!(dsp, tmp_map_ui)
        root = getRoot(tmp_map_ui)[2:end]
        println("Faust OSC application '", root, "' is running on UDP ports ", inport, ", ", outport)       
        osc_ui
	end
    dsp::dsp
    map_ui::MapUI
    rcv_socket::UDPSocket
    snd_socket::UDPSocket
    inport::Int
    outport::Int
end
    
# Receive and decode incoming OSC messages
function run(ui_interface::OSCUI, block::Bool=true)
    
    # Send current state of all input/output controllers
    function sendMessages()
        while true
            for item in getZoneMap(ui_interface.map_ui)
                path = item.first
                ctrl_msg = OpenSoundControl.message(path, "f", getParamValue(ui_interface.map_ui, path))
                send(ui_interface.snd_socket, ip"127.0.0.1", ui_interface.outport, ctrl_msg.data)
            end
            sleep(0.5)
        end
    end

        # Receive OSC messages 1) to setup 2) to update input controllers
    function receiveMessages()
        while true
            message = OscMsg(recv(ui_interface.rcv_socket))
            osc_path = path(message)
            osc_value = message[1]
            root = getRoot(ui_interface.map_ui)
            if (typeof(osc_value) == Float32)
                setParamValue!(ui_interface.map_ui, osc_path, osc_value);
            elseif (typeof(osc_value) == String && osc_path == "/*" && osc_value == "hello") 
                hello_msg = OpenSoundControl.message(root, "sii", "127.0.0.1", Int32(ui_interface.inport), Int32(ui_interface.outport))
                send(ui_interface.snd_socket, ip"127.0.0.1", ui_interface.outport, hello_msg.data)
                println("Faust OSC application '", root[2:end], "' received the 'hello' message")       
            elseif (root == osc_path && typeof(osc_value) == String && osc_value == "json") 
                json_msg = OpenSoundControl.message(root, "ss", "json", getJSON(ui_interface.dsp))
                send(ui_interface.snd_socket, ip"127.0.0.1", ui_interface.outport, json_msg.data)
                println("Faust OSC application '", root[2:end], "' received the 'json' message")
            elseif (root == osc_path && typeof(osc_value) == String && osc_value == "get")
                for item in getZoneMap(ui_interface.map_ui)
                    path = item.first
                    zone = item.second
                    ctrl_msg = OpenSoundControl.message(path, "fff", zone.init, zone.min, zone.max)
                    send(ui_interface.snd_socket, ip"127.0.0.1", ui_interface.outport, ctrl_msg.data)
                end
            end 
        end
    end

        # Start send task
    task = Task(sendMessages)
    schedule(task)

    # Start block receive function
    if (block) 
        receiveMessages()
    else
        Threads.@spawn receiveMessages()
    end
end

# Does not work ?
# MacroTools.@forward OSCUI.map_ui openTabBox, openHorizontalBox, openVerticalBox, closeBox, addButton, addCheckButton, addHorizontalSlider, addHorizontalSlider, addNumEntry, addHorizontalBargraph, addVerticalBargraph
 
# -- widget's layouts
function openTabBox!(ui_interface::OSCUI, label::String)
    openTabBox!(ui_interface.map_ui, label)
end
function openHorizontalBox!(ui_interface::OSCUI, label::String)
    openHorizontalBox!(ui_interface.map_ui, label)
end
function openVerticalBox!(ui_interface::OSCUI, label::String)
    openVerticalBox!(ui_interface.map_ui, label)
end
function closeBox!(ui_interface::OSCUI)
    closeBox!(ui_interface.map_ui)
end

# -- active widgets
function addButton!(ui_interface::OSCUI, label::String, param::Symbol) 
    addButton!(ui_interface.map_ui, label, param)
end

function addCheckButton!(ui_interface::OSCUI, label::String, param::Symbol) 
    addCheckButton!(ui_interface.map_ui, label, param)
end

function addHorizontalSlider!(ui_interface::OSCUI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
    addHorizontalSlider!(ui_interface.map_ui, label, param, init, min, max, step)
end

function addVerticalSlider!(ui_interface::OSCUI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
    addVerticalSlider!(ui_interface.map_ui, label, param, init, min, max, step)
end

function addNumEntry!(ui_interface::OSCUI, label::String, param::Symbol, init::FAUSTFLOAT, min::FAUSTFLOAT, max::FAUSTFLOAT, step::FAUSTFLOAT) 
    addNumEntry!(ui_interface.map_ui, label, param, init, min, max, step)
end

# -- passive widgets
function addHorizontalBargraph!(ui_interface::OSCUI, label::String, param::Symbol, min::FAUSTFLOAT, max::FAUSTFLOAT)
    addHorizontalBargraph!(ui_interface.map_ui, label, param, min, max)
end

function addVerticalBargraph!(ui_interface::OSCUI, label::String, param::Symbol, min::FAUSTFLOAT, max::FAUSTFLOAT)
    addVerticalBargraph!(ui_interface.map_ui, label, param, min, max)
end# ************************************************************************
# FAUST Architecture File
# Copyright (C) 2021 GRAME, Centre National de Creation Musicale
# ---------------------------------------------------------------------

# This is sample code. This file is provided as an example of minimal
# FAUST architecture file. Redistribution and use in source and binary
# forms, with or without modification, in part or in full are permitted.
# In particular you can create a derived work of this FAUST architecture
# and distribute that work under terms of your choice.

# This sample code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# ************************************************************************

const FAUSTFLOAT = Float32

# Architectures are conditionally included (since they may be already inlined in the file)
try 
    include("/usr/local/share/faust/julia/audio/portaudio.jl")
    include("/usr/local/share/faust/julia/gui/MapUI.jl")
    include("/usr/local/share/faust/julia/gui/GTKUI.jl")
    include("/usr/local/share/faust/julia/gui/OSCUI.jl")
catch 
end

# Generated code
#=
Code generated with Faust version 2.34.3
Compilation options: -a /usr/local/share/faust/julia/portaudio_gtk.jl -lang julia -es 1 -single -ftz 0
=#

using StaticArrays
const REAL = Float32
pow(x, y) = x ^ y
rint(x) = round(x, Base.Rounding.RoundNearest)
remainder(x, y) = rem(x, y, Base.Rounding.RoundNearest)

mutable struct mydsp{T} <: dsp
	fHslider0::FAUSTFLOAT 
	ftbl0::Vector{T} 
	fHslider1::FAUSTFLOAT 
	fVec0::Vector{T} 
	fSampleRate::Int32 
	iConst0::Int32 
	iRec1::Vector{Int32} 
	iVec1::Vector{Int32} 
	fRec2::Vector{T} 
	iRec3::Vector{Int32} 
	iRec4::Vector{Int32} 
	ftbl1::Vector{T} 
	fVslider0::FAUSTFLOAT 
	iVec2::Vector{Int32} 
	iRec6::Vector{Int32} 
	iVec3::Vector{Int32} 
	fRec5::Vector{T} 
	ftbl2::Vector{T} 
	fVslider1::FAUSTFLOAT 
	iVec4::Vector{Int32} 
	iRec7::Vector{Int32} 
	IOTA::Int32 
	fVec5::Vector{T} 
	fRec0::Vector{T} 
	ftbl3::Vector{T} 
	fVslider2::FAUSTFLOAT 
	iVec6::Vector{Int32} 
	iRec10::Vector{Int32} 
	iVec7::Vector{Int32} 
	fRec9::Vector{T} 
	fVec8::Vector{T} 
	fRec8::Vector{T} 
	iVec9::Vector{Int32} 
	fRec12::Vector{T} 
	fVec10::Vector{T} 
	fRec11::Vector{T} 
	iVec11::Vector{Int32} 
	fRec14::Vector{T} 
	fVec12::Vector{T} 
	fRec13::Vector{T} 
	iVec13::Vector{Int32} 
	fRec16::Vector{T} 
	fVec14::Vector{T} 
	fRec15::Vector{T} 
	iVec15::Vector{Int32} 
	fRec18::Vector{T} 
	fVec16::Vector{T} 
	fRec17::Vector{T} 
	iVec17::Vector{Int32} 
	fRec20::Vector{T} 
	fVec18::Vector{T} 
	fRec19::Vector{T} 
	iVec19::Vector{Int32} 
	fRec22::Vector{T} 
	fVec20::Vector{T} 
	fRec21::Vector{T} 
	iVec21::Vector{Int32} 
	fRec24::Vector{T} 
	fVec22::Vector{T} 
	fRec23::Vector{T} 
	iVec23::Vector{Int32} 
	fRec26::Vector{T} 
	fVec24::Vector{T} 
	fRec25::Vector{T} 
	iVec25::Vector{Int32} 
	fRec28::Vector{T} 
	fVec26::Vector{T} 
	fRec27::Vector{T} 
	iVec27::Vector{Int32} 
	fRec30::Vector{T} 
	fVec28::Vector{T} 
	fRec29::Vector{T} 
	iVec29::Vector{Int32} 
	fRec32::Vector{T} 
	fVec30::Vector{T} 
	fRec31::Vector{T} 
	iVec31::Vector{Int32} 
	fRec34::Vector{T} 
	fVec32::Vector{T} 
	fRec33::Vector{T} 
	iVec33::Vector{Int32} 
	fRec36::Vector{T} 
	fVec34::Vector{T} 
	fRec35::Vector{T} 
	iVec35::Vector{Int32} 
	fRec38::Vector{T} 
	fVec36::Vector{T} 
	fRec37::Vector{T} 
	iVec37::Vector{Int32} 
	fRec40::Vector{T} 
	fVec38::Vector{T} 
	fRec39::Vector{T} 
	iVec39::Vector{Int32} 
	fRec42::Vector{T} 
	fVec40::Vector{T} 
	fRec41::Vector{T} 
	iVec41::Vector{Int32} 
	fRec44::Vector{T} 
	fVec42::Vector{T} 
	fRec43::Vector{T} 
	iVec43::Vector{Int32} 
	fRec46::Vector{T} 
	fVec44::Vector{T} 
	fRec45::Vector{T} 
	iVec45::Vector{Int32} 
	fRec48::Vector{T} 
	fVec46::Vector{T} 
	fRec47::Vector{T} 
	iVec47::Vector{Int32} 
	fRec50::Vector{T} 
	fVec48::Vector{T} 
	fRec49::Vector{T} 
	ftbl4::Vector{T} 
	fVslider3::FAUSTFLOAT 
	iVec49::Vector{Int32} 
	iRec53::Vector{Int32} 
	iVec50::Vector{Int32} 
	fRec52::Vector{T} 
	fVec51::Vector{T} 
	fRec51::Vector{T} 
	iVec52::Vector{Int32} 
	fRec55::Vector{T} 
	fVec53::Vector{T} 
	fRec54::Vector{T} 
	iVec54::Vector{Int32} 
	fRec57::Vector{T} 
	fVec55::Vector{T} 
	fRec56::Vector{T} 
	iVec56::Vector{Int32} 
	fRec59::Vector{T} 
	fVec57::Vector{T} 
	fRec58::Vector{T} 
	iVec58::Vector{Int32} 
	fRec61::Vector{T} 
	fVec59::Vector{T} 
	fRec60::Vector{T} 
	iVec60::Vector{Int32} 
	fRec63::Vector{T} 
	fVec61::Vector{T} 
	fRec62::Vector{T} 
	iVec62::Vector{Int32} 
	fRec65::Vector{T} 
	fVec63::Vector{T} 
	fRec64::Vector{T} 
	iVec64::Vector{Int32} 
	fRec67::Vector{T} 
	fVec65::Vector{T} 
	fRec66::Vector{T} 
	iVec66::Vector{Int32} 
	fRec69::Vector{T} 
	fVec67::Vector{T} 
	fRec68::Vector{T} 
	iVec68::Vector{Int32} 
	fRec71::Vector{T} 
	fVec69::Vector{T} 
	fRec70::Vector{T} 
	iVec70::Vector{Int32} 
	fRec73::Vector{T} 
	fVec71::Vector{T} 
	fRec72::Vector{T} 
	mydsp{T}() where {T} = begin
		dsp = new{T}()
		dsp.ftbl0 = zeros(T, 16)
		dsp.fVec0 = zeros(T, 2)
		dsp.iRec1 = zeros(Int32, 2)
		dsp.iVec1 = zeros(Int32, 2)
		dsp.fRec2 = zeros(T, 2)
		dsp.iRec3 = zeros(Int32, 2)
		dsp.iRec4 = zeros(Int32, 2)
		dsp.ftbl1 = zeros(T, 16)
		dsp.iVec2 = zeros(Int32, 2)
		dsp.iRec6 = zeros(Int32, 2)
		dsp.iVec3 = zeros(Int32, 2)
		dsp.fRec5 = zeros(T, 2)
		dsp.ftbl2 = zeros(T, 16)
		dsp.iVec4 = zeros(Int32, 2)
		dsp.iRec7 = zeros(Int32, 2)
		dsp.fVec5 = zeros(T, 128)
		dsp.fRec0 = zeros(T, 3)
		dsp.ftbl3 = zeros(T, 16)
		dsp.iVec6 = zeros(Int32, 2)
		dsp.iRec10 = zeros(Int32, 2)
		dsp.iVec7 = zeros(Int32, 2)
		dsp.fRec9 = zeros(T, 2)
		dsp.fVec8 = zeros(T, 64)
		dsp.fRec8 = zeros(T, 3)
		dsp.iVec9 = zeros(Int32, 2)
		dsp.fRec12 = zeros(T, 2)
		dsp.fVec10 = zeros(T, 128)
		dsp.fRec11 = zeros(T, 3)
		dsp.iVec11 = zeros(Int32, 2)
		dsp.fRec14 = zeros(T, 2)
		dsp.fVec12 = zeros(T, 64)
		dsp.fRec13 = zeros(T, 3)
		dsp.iVec13 = zeros(Int32, 2)
		dsp.fRec16 = zeros(T, 2)
		dsp.fVec14 = zeros(T, 256)
		dsp.fRec15 = zeros(T, 3)
		dsp.iVec15 = zeros(Int32, 2)
		dsp.fRec18 = zeros(T, 2)
		dsp.fVec16 = zeros(T, 128)
		dsp.fRec17 = zeros(T, 3)
		dsp.iVec17 = zeros(Int32, 2)
		dsp.fRec20 = zeros(T, 2)
		dsp.fVec18 = zeros(T, 256)
		dsp.fRec19 = zeros(T, 3)
		dsp.iVec19 = zeros(Int32, 2)
		dsp.fRec22 = zeros(T, 2)
		dsp.fVec20 = zeros(T, 128)
		dsp.fRec21 = zeros(T, 3)
		dsp.iVec21 = zeros(Int32, 2)
		dsp.fRec24 = zeros(T, 2)
		dsp.fVec22 = zeros(T, 256)
		dsp.fRec23 = zeros(T, 3)
		dsp.iVec23 = zeros(Int32, 2)
		dsp.fRec26 = zeros(T, 2)
		dsp.fVec24 = zeros(T, 128)
		dsp.fRec25 = zeros(T, 3)
		dsp.iVec25 = zeros(Int32, 2)
		dsp.fRec28 = zeros(T, 2)
		dsp.fVec26 = zeros(T, 256)
		dsp.fRec27 = zeros(T, 3)
		dsp.iVec27 = zeros(Int32, 2)
		dsp.fRec30 = zeros(T, 2)
		dsp.fVec28 = zeros(T, 128)
		dsp.fRec29 = zeros(T, 3)
		dsp.iVec29 = zeros(Int32, 2)
		dsp.fRec32 = zeros(T, 2)
		dsp.fVec30 = zeros(T, 256)
		dsp.fRec31 = zeros(T, 3)
		dsp.iVec31 = zeros(Int32, 2)
		dsp.fRec34 = zeros(T, 2)
		dsp.fVec32 = zeros(T, 128)
		dsp.fRec33 = zeros(T, 3)
		dsp.iVec33 = zeros(Int32, 2)
		dsp.fRec36 = zeros(T, 2)
		dsp.fVec34 = zeros(T, 512)
		dsp.fRec35 = zeros(T, 3)
		dsp.iVec35 = zeros(Int32, 2)
		dsp.fRec38 = zeros(T, 2)
		dsp.fVec36 = zeros(T, 256)
		dsp.fRec37 = zeros(T, 3)
		dsp.iVec37 = zeros(Int32, 2)
		dsp.fRec40 = zeros(T, 2)
		dsp.fVec38 = zeros(T, 512)
		dsp.fRec39 = zeros(T, 3)
		dsp.iVec39 = zeros(Int32, 2)
		dsp.fRec42 = zeros(T, 2)
		dsp.fVec40 = zeros(T, 256)
		dsp.fRec41 = zeros(T, 3)
		dsp.iVec41 = zeros(Int32, 2)
		dsp.fRec44 = zeros(T, 2)
		dsp.fVec42 = zeros(T, 512)
		dsp.fRec43 = zeros(T, 3)
		dsp.iVec43 = zeros(Int32, 2)
		dsp.fRec46 = zeros(T, 2)
		dsp.fVec44 = zeros(T, 256)
		dsp.fRec45 = zeros(T, 3)
		dsp.iVec45 = zeros(Int32, 2)
		dsp.fRec48 = zeros(T, 2)
		dsp.fVec46 = zeros(T, 128)
		dsp.fRec47 = zeros(T, 3)
		dsp.iVec47 = zeros(Int32, 2)
		dsp.fRec50 = zeros(T, 2)
		dsp.fVec48 = zeros(T, 64)
		dsp.fRec49 = zeros(T, 3)
		dsp.ftbl4 = zeros(T, 16)
		dsp.iVec49 = zeros(Int32, 2)
		dsp.iRec53 = zeros(Int32, 2)
		dsp.iVec50 = zeros(Int32, 2)
		dsp.fRec52 = zeros(T, 2)
		dsp.fVec51 = zeros(T, 128)
		dsp.fRec51 = zeros(T, 3)
		dsp.iVec52 = zeros(Int32, 2)
		dsp.fRec55 = zeros(T, 2)
		dsp.fVec53 = zeros(T, 128)
		dsp.fRec54 = zeros(T, 3)
		dsp.iVec54 = zeros(Int32, 2)
		dsp.fRec57 = zeros(T, 2)
		dsp.fVec55 = zeros(T, 128)
		dsp.fRec56 = zeros(T, 3)
		dsp.iVec56 = zeros(Int32, 2)
		dsp.fRec59 = zeros(T, 2)
		dsp.fVec57 = zeros(T, 64)
		dsp.fRec58 = zeros(T, 3)
		dsp.iVec58 = zeros(Int32, 2)
		dsp.fRec61 = zeros(T, 2)
		dsp.fVec59 = zeros(T, 64)
		dsp.fRec60 = zeros(T, 3)
		dsp.iVec60 = zeros(Int32, 2)
		dsp.fRec63 = zeros(T, 2)
		dsp.fVec61 = zeros(T, 64)
		dsp.fRec62 = zeros(T, 3)
		dsp.iVec62 = zeros(Int32, 2)
		dsp.fRec65 = zeros(T, 2)
		dsp.fVec63 = zeros(T, 64)
		dsp.fRec64 = zeros(T, 3)
		dsp.iVec64 = zeros(Int32, 2)
		dsp.fRec67 = zeros(T, 2)
		dsp.fVec65 = zeros(T, 64)
		dsp.fRec66 = zeros(T, 3)
		dsp.iVec66 = zeros(Int32, 2)
		dsp.fRec69 = zeros(T, 2)
		dsp.fVec67 = zeros(T, 32)
		dsp.fRec68 = zeros(T, 3)
		dsp.iVec68 = zeros(Int32, 2)
		dsp.fRec71 = zeros(T, 2)
		dsp.fVec69 = zeros(T, 32)
		dsp.fRec70 = zeros(T, 3)
		dsp.iVec70 = zeros(Int32, 2)
		dsp.fRec73 = zeros(T, 2)
		dsp.fVec71 = zeros(T, 32)
		dsp.fRec72 = zeros(T, 3)
		dsp
	end
end

function metadata!(dsp::mydsp{T}, m::Meta) where {T}
	declare!(m, "author", "Yann Orlarey");
	declare!(m, "compile_options", "-a /usr/local/share/faust/julia/portaudio_gtk.jl -lang julia -es 1 -single -ftz 0");
	declare!(m, "filename", "kisana.dsp");
	declare!(m, "math.lib/author", "GRAME");
	declare!(m, "math.lib/copyright", "GRAME");
	declare!(m, "math.lib/deprecated", "This library is deprecated and is not maintained anymore. It will be removed in August 2017.");
	declare!(m, "math.lib/license", "LGPL with exception");
	declare!(m, "math.lib/name", "Math Library");
	declare!(m, "math.lib/version", "1.0");
	declare!(m, "music.lib/author", "GRAME");
	declare!(m, "music.lib/copyright", "GRAME");
	declare!(m, "music.lib/deprecated", "This library is deprecated and is not maintained anymore. It will be removed in August 2017.");
	declare!(m, "music.lib/license", "LGPL with exception");
	declare!(m, "music.lib/name", "Music Library");
	declare!(m, "music.lib/version", "1.0");
	declare!(m, "name", "kisana");
end

function getSampleRate(dsp::mydsp{T}) where {T}
	return dsp.fSampleRate 
end

function getNumInputs(dsp::mydsp{T}) where {T}
	return Int32(0) 
end
function getNumOutputs(dsp::mydsp{T}) where {T}
	return Int32(2) 
end

function classInit!(dsp::mydsp{T}, sample_rate::Int32) where {T}
end

function instanceResetUserInterface!(dsp::mydsp{T}) where {T}
	dsp.fHslider0 = FAUSTFLOAT(-20.0f0) 
	dsp.fHslider1 = FAUSTFLOAT(0.0f0) 
	dsp.fVslider0 = FAUSTFLOAT(0.0f0) 
	dsp.fVslider1 = FAUSTFLOAT(0.0f0) 
	dsp.fVslider2 = FAUSTFLOAT(0.0f0) 
	dsp.fVslider3 = FAUSTFLOAT(0.0f0) 
end

function instanceClear!(dsp::mydsp{T}) where {T}
	@inbounds for l0 in 0:1
		dsp.fVec0[l0+1] = 0.0f0 
	end
	@inbounds for l1 in 0:1
		dsp.iRec1[l1+1] = Int32(0) 
	end
	@inbounds for l2 in 0:1
		dsp.iVec1[l2+1] = Int32(0) 
	end
	@inbounds for l3 in 0:1
		dsp.fRec2[l3+1] = 0.0f0 
	end
	@inbounds for l4 in 0:1
		dsp.iRec3[l4+1] = Int32(0) 
	end
	@inbounds for l5 in 0:1
		dsp.iRec4[l5+1] = Int32(0) 
	end
	@inbounds for l6 in 0:1
		dsp.iVec2[l6+1] = Int32(0) 
	end
	@inbounds for l7 in 0:1
		dsp.iRec6[l7+1] = Int32(0) 
	end
	@inbounds for l8 in 0:1
		dsp.iVec3[l8+1] = Int32(0) 
	end
	@inbounds for l9 in 0:1
		dsp.fRec5[l9+1] = 0.0f0 
	end
	@inbounds for l10 in 0:1
		dsp.iVec4[l10+1] = Int32(0) 
	end
	@inbounds for l11 in 0:1
		dsp.iRec7[l11+1] = Int32(0) 
	end
	dsp.IOTA = Int32(0) 
	@inbounds for l12 in 0:127
		dsp.fVec5[l12+1] = 0.0f0 
	end
	@inbounds for l13 in 0:2
		dsp.fRec0[l13+1] = 0.0f0 
	end
	@inbounds for l14 in 0:1
		dsp.iVec6[l14+1] = Int32(0) 
	end
	@inbounds for l15 in 0:1
		dsp.iRec10[l15+1] = Int32(0) 
	end
	@inbounds for l16 in 0:1
		dsp.iVec7[l16+1] = Int32(0) 
	end
	@inbounds for l17 in 0:1
		dsp.fRec9[l17+1] = 0.0f0 
	end
	@inbounds for l18 in 0:63
		dsp.fVec8[l18+1] = 0.0f0 
	end
	@inbounds for l19 in 0:2
		dsp.fRec8[l19+1] = 0.0f0 
	end
	@inbounds for l20 in 0:1
		dsp.iVec9[l20+1] = Int32(0) 
	end
	@inbounds for l21 in 0:1
		dsp.fRec12[l21+1] = 0.0f0 
	end
	@inbounds for l22 in 0:127
		dsp.fVec10[l22+1] = 0.0f0 
	end
	@inbounds for l23 in 0:2
		dsp.fRec11[l23+1] = 0.0f0 
	end
	@inbounds for l24 in 0:1
		dsp.iVec11[l24+1] = Int32(0) 
	end
	@inbounds for l25 in 0:1
		dsp.fRec14[l25+1] = 0.0f0 
	end
	@inbounds for l26 in 0:63
		dsp.fVec12[l26+1] = 0.0f0 
	end
	@inbounds for l27 in 0:2
		dsp.fRec13[l27+1] = 0.0f0 
	end
	@inbounds for l28 in 0:1
		dsp.iVec13[l28+1] = Int32(0) 
	end
	@inbounds for l29 in 0:1
		dsp.fRec16[l29+1] = 0.0f0 
	end
	@inbounds for l30 in 0:255
		dsp.fVec14[l30+1] = 0.0f0 
	end
	@inbounds for l31 in 0:2
		dsp.fRec15[l31+1] = 0.0f0 
	end
	@inbounds for l32 in 0:1
		dsp.iVec15[l32+1] = Int32(0) 
	end
	@inbounds for l33 in 0:1
		dsp.fRec18[l33+1] = 0.0f0 
	end
	@inbounds for l34 in 0:127
		dsp.fVec16[l34+1] = 0.0f0 
	end
	@inbounds for l35 in 0:2
		dsp.fRec17[l35+1] = 0.0f0 
	end
	@inbounds for l36 in 0:1
		dsp.iVec17[l36+1] = Int32(0) 
	end
	@inbounds for l37 in 0:1
		dsp.fRec20[l37+1] = 0.0f0 
	end
	@inbounds for l38 in 0:255
		dsp.fVec18[l38+1] = 0.0f0 
	end
	@inbounds for l39 in 0:2
		dsp.fRec19[l39+1] = 0.0f0 
	end
	@inbounds for l40 in 0:1
		dsp.iVec19[l40+1] = Int32(0) 
	end
	@inbounds for l41 in 0:1
		dsp.fRec22[l41+1] = 0.0f0 
	end
	@inbounds for l42 in 0:127
		dsp.fVec20[l42+1] = 0.0f0 
	end
	@inbounds for l43 in 0:2
		dsp.fRec21[l43+1] = 0.0f0 
	end
	@inbounds for l44 in 0:1
		dsp.iVec21[l44+1] = Int32(0) 
	end
	@inbounds for l45 in 0:1
		dsp.fRec24[l45+1] = 0.0f0 
	end
	@inbounds for l46 in 0:255
		dsp.fVec22[l46+1] = 0.0f0 
	end
	@inbounds for l47 in 0:2
		dsp.fRec23[l47+1] = 0.0f0 
	end
	@inbounds for l48 in 0:1
		dsp.iVec23[l48+1] = Int32(0) 
	end
	@inbounds for l49 in 0:1
		dsp.fRec26[l49+1] = 0.0f0 
	end
	@inbounds for l50 in 0:127
		dsp.fVec24[l50+1] = 0.0f0 
	end
	@inbounds for l51 in 0:2
		dsp.fRec25[l51+1] = 0.0f0 
	end
	@inbounds for l52 in 0:1
		dsp.iVec25[l52+1] = Int32(0) 
	end
	@inbounds for l53 in 0:1
		dsp.fRec28[l53+1] = 0.0f0 
	end
	@inbounds for l54 in 0:255
		dsp.fVec26[l54+1] = 0.0f0 
	end
	@inbounds for l55 in 0:2
		dsp.fRec27[l55+1] = 0.0f0 
	end
	@inbounds for l56 in 0:1
		dsp.iVec27[l56+1] = Int32(0) 
	end
	@inbounds for l57 in 0:1
		dsp.fRec30[l57+1] = 0.0f0 
	end
	@inbounds for l58 in 0:127
		dsp.fVec28[l58+1] = 0.0f0 
	end
	@inbounds for l59 in 0:2
		dsp.fRec29[l59+1] = 0.0f0 
	end
	@inbounds for l60 in 0:1
		dsp.iVec29[l60+1] = Int32(0) 
	end
	@inbounds for l61 in 0:1
		dsp.fRec32[l61+1] = 0.0f0 
	end
	@inbounds for l62 in 0:255
		dsp.fVec30[l62+1] = 0.0f0 
	end
	@inbounds for l63 in 0:2
		dsp.fRec31[l63+1] = 0.0f0 
	end
	@inbounds for l64 in 0:1
		dsp.iVec31[l64+1] = Int32(0) 
	end
	@inbounds for l65 in 0:1
		dsp.fRec34[l65+1] = 0.0f0 
	end
	@inbounds for l66 in 0:127
		dsp.fVec32[l66+1] = 0.0f0 
	end
	@inbounds for l67 in 0:2
		dsp.fRec33[l67+1] = 0.0f0 
	end
	@inbounds for l68 in 0:1
		dsp.iVec33[l68+1] = Int32(0) 
	end
	@inbounds for l69 in 0:1
		dsp.fRec36[l69+1] = 0.0f0 
	end
	@inbounds for l70 in 0:511
		dsp.fVec34[l70+1] = 0.0f0 
	end
	@inbounds for l71 in 0:2
		dsp.fRec35[l71+1] = 0.0f0 
	end
	@inbounds for l72 in 0:1
		dsp.iVec35[l72+1] = Int32(0) 
	end
	@inbounds for l73 in 0:1
		dsp.fRec38[l73+1] = 0.0f0 
	end
	@inbounds for l74 in 0:255
		dsp.fVec36[l74+1] = 0.0f0 
	end
	@inbounds for l75 in 0:2
		dsp.fRec37[l75+1] = 0.0f0 
	end
	@inbounds for l76 in 0:1
		dsp.iVec37[l76+1] = Int32(0) 
	end
	@inbounds for l77 in 0:1
		dsp.fRec40[l77+1] = 0.0f0 
	end
	@inbounds for l78 in 0:511
		dsp.fVec38[l78+1] = 0.0f0 
	end
	@inbounds for l79 in 0:2
		dsp.fRec39[l79+1] = 0.0f0 
	end
	@inbounds for l80 in 0:1
		dsp.iVec39[l80+1] = Int32(0) 
	end
	@inbounds for l81 in 0:1
		dsp.fRec42[l81+1] = 0.0f0 
	end
	@inbounds for l82 in 0:255
		dsp.fVec40[l82+1] = 0.0f0 
	end
	@inbounds for l83 in 0:2
		dsp.fRec41[l83+1] = 0.0f0 
	end
	@inbounds for l84 in 0:1
		dsp.iVec41[l84+1] = Int32(0) 
	end
	@inbounds for l85 in 0:1
		dsp.fRec44[l85+1] = 0.0f0 
	end
	@inbounds for l86 in 0:511
		dsp.fVec42[l86+1] = 0.0f0 
	end
	@inbounds for l87 in 0:2
		dsp.fRec43[l87+1] = 0.0f0 
	end
	@inbounds for l88 in 0:1
		dsp.iVec43[l88+1] = Int32(0) 
	end
	@inbounds for l89 in 0:1
		dsp.fRec46[l89+1] = 0.0f0 
	end
	@inbounds for l90 in 0:255
		dsp.fVec44[l90+1] = 0.0f0 
	end
	@inbounds for l91 in 0:2
		dsp.fRec45[l91+1] = 0.0f0 
	end
	@inbounds for l92 in 0:1
		dsp.iVec45[l92+1] = Int32(0) 
	end
	@inbounds for l93 in 0:1
		dsp.fRec48[l93+1] = 0.0f0 
	end
	@inbounds for l94 in 0:127
		dsp.fVec46[l94+1] = 0.0f0 
	end
	@inbounds for l95 in 0:2
		dsp.fRec47[l95+1] = 0.0f0 
	end
	@inbounds for l96 in 0:1
		dsp.iVec47[l96+1] = Int32(0) 
	end
	@inbounds for l97 in 0:1
		dsp.fRec50[l97+1] = 0.0f0 
	end
	@inbounds for l98 in 0:63
		dsp.fVec48[l98+1] = 0.0f0 
	end
	@inbounds for l99 in 0:2
		dsp.fRec49[l99+1] = 0.0f0 
	end
	@inbounds for l100 in 0:1
		dsp.iVec49[l100+1] = Int32(0) 
	end
	@inbounds for l101 in 0:1
		dsp.iRec53[l101+1] = Int32(0) 
	end
	@inbounds for l102 in 0:1
		dsp.iVec50[l102+1] = Int32(0) 
	end
	@inbounds for l103 in 0:1
		dsp.fRec52[l103+1] = 0.0f0 
	end
	@inbounds for l104 in 0:127
		dsp.fVec51[l104+1] = 0.0f0 
	end
	@inbounds for l105 in 0:2
		dsp.fRec51[l105+1] = 0.0f0 
	end
	@inbounds for l106 in 0:1
		dsp.iVec52[l106+1] = Int32(0) 
	end
	@inbounds for l107 in 0:1
		dsp.fRec55[l107+1] = 0.0f0 
	end
	@inbounds for l108 in 0:127
		dsp.fVec53[l108+1] = 0.0f0 
	end
	@inbounds for l109 in 0:2
		dsp.fRec54[l109+1] = 0.0f0 
	end
	@inbounds for l110 in 0:1
		dsp.iVec54[l110+1] = Int32(0) 
	end
	@inbounds for l111 in 0:1
		dsp.fRec57[l111+1] = 0.0f0 
	end
	@inbounds for l112 in 0:127
		dsp.fVec55[l112+1] = 0.0f0 
	end
	@inbounds for l113 in 0:2
		dsp.fRec56[l113+1] = 0.0f0 
	end
	@inbounds for l114 in 0:1
		dsp.iVec56[l114+1] = Int32(0) 
	end
	@inbounds for l115 in 0:1
		dsp.fRec59[l115+1] = 0.0f0 
	end
	@inbounds for l116 in 0:63
		dsp.fVec57[l116+1] = 0.0f0 
	end
	@inbounds for l117 in 0:2
		dsp.fRec58[l117+1] = 0.0f0 
	end
	@inbounds for l118 in 0:1
		dsp.iVec58[l118+1] = Int32(0) 
	end
	@inbounds for l119 in 0:1
		dsp.fRec61[l119+1] = 0.0f0 
	end
	@inbounds for l120 in 0:63
		dsp.fVec59[l120+1] = 0.0f0 
	end
	@inbounds for l121 in 0:2
		dsp.fRec60[l121+1] = 0.0f0 
	end
	@inbounds for l122 in 0:1
		dsp.iVec60[l122+1] = Int32(0) 
	end
	@inbounds for l123 in 0:1
		dsp.fRec63[l123+1] = 0.0f0 
	end
	@inbounds for l124 in 0:63
		dsp.fVec61[l124+1] = 0.0f0 
	end
	@inbounds for l125 in 0:2
		dsp.fRec62[l125+1] = 0.0f0 
	end
	@inbounds for l126 in 0:1
		dsp.iVec62[l126+1] = Int32(0) 
	end
	@inbounds for l127 in 0:1
		dsp.fRec65[l127+1] = 0.0f0 
	end
	@inbounds for l128 in 0:63
		dsp.fVec63[l128+1] = 0.0f0 
	end
	@inbounds for l129 in 0:2
		dsp.fRec64[l129+1] = 0.0f0 
	end
	@inbounds for l130 in 0:1
		dsp.iVec64[l130+1] = Int32(0) 
	end
	@inbounds for l131 in 0:1
		dsp.fRec67[l131+1] = 0.0f0 
	end
	@inbounds for l132 in 0:63
		dsp.fVec65[l132+1] = 0.0f0 
	end
	@inbounds for l133 in 0:2
		dsp.fRec66[l133+1] = 0.0f0 
	end
	@inbounds for l134 in 0:1
		dsp.iVec66[l134+1] = Int32(0) 
	end
	@inbounds for l135 in 0:1
		dsp.fRec69[l135+1] = 0.0f0 
	end
	@inbounds for l136 in 0:31
		dsp.fVec67[l136+1] = 0.0f0 
	end
	@inbounds for l137 in 0:2
		dsp.fRec68[l137+1] = 0.0f0 
	end
	@inbounds for l138 in 0:1
		dsp.iVec68[l138+1] = Int32(0) 
	end
	@inbounds for l139 in 0:1
		dsp.fRec71[l139+1] = 0.0f0 
	end
	@inbounds for l140 in 0:31
		dsp.fVec69[l140+1] = 0.0f0 
	end
	@inbounds for l141 in 0:2
		dsp.fRec70[l141+1] = 0.0f0 
	end
	@inbounds for l142 in 0:1
		dsp.iVec70[l142+1] = Int32(0) 
	end
	@inbounds for l143 in 0:1
		dsp.fRec73[l143+1] = 0.0f0 
	end
	@inbounds for l144 in 0:31
		dsp.fVec71[l144+1] = 0.0f0 
	end
	@inbounds for l145 in 0:2
		dsp.fRec72[l145+1] = 0.0f0 
	end
end

function instanceConstants!(dsp::mydsp{T}, sample_rate::Int32) where {T}
	dsp.fSampleRate = sample_rate 
	@inbounds for i1 in 0:15
		dsp.ftbl0[i1+1] = 0.0f0 
	end
	dsp.iConst0 = trunc(Int32, (0.166666672f0 * min(192000.0f0, max(1.0f0, T(dsp.fSampleRate))))) 
	@inbounds for i1 in 0:15
		dsp.ftbl1[i1+1] = 0.0f0 
	end
	@inbounds for i1 in 0:15
		dsp.ftbl2[i1+1] = 0.0f0 
	end
	@inbounds for i1 in 0:15
		dsp.ftbl3[i1+1] = 0.0f0 
	end
	@inbounds for i1 in 0:15
		dsp.ftbl4[i1+1] = 0.0f0 
	end
end

function instanceInit!(dsp::mydsp{T}, sample_rate::Int32) where {T}
	instanceConstants!(dsp, sample_rate)
	instanceResetUserInterface!(dsp)
	instanceClear!(dsp)
end

function init!(dsp::mydsp{T}, sample_rate::Int32) where {T}
	classInit!(dsp, sample_rate)
	instanceInit!(dsp, sample_rate)
end

function getJSON(dsp::mydsp{T}) where {T}
	return "{\"name\": \"kisana\",\"filename\": \"kisana.dsp\",\"version\": \"2.34.3\",\"compile_options\": \"-a /usr/local/share/faust/julia/portaudio_gtk.jl -lang julia -es 1 -single -ftz 0\",\"library_list\": [\"/usr/local/share/faust/music.lib\",\"/usr/local/share/faust/math.lib\"],\"include_pathnames\": [\"/usr/local/share/faust\",\"/usr/local/share/faust\",\"/usr/share/faust\",\".\",\"/tmp/sessions/F215B271A610C7B8E520CB28532733148424CCB0/julia/portaudiojulia\"],\"inputs\": 0,\"outputs\": 2,\"meta\": [ { \"author\": \"Yann Orlarey\" },{ \"compile_options\": \"-a /usr/local/share/faust/julia/portaudio_gtk.jl -lang julia -es 1 -single -ftz 0\" },{ \"filename\": \"kisana.dsp\" },{ \"math.lib/author\": \"GRAME\" },{ \"math.lib/copyright\": \"GRAME\" },{ \"math.lib/deprecated\": \"This library is deprecated and is not maintained anymore. It will be removed in August 2017.\" },{ \"math.lib/license\": \"LGPL with exception\" },{ \"math.lib/name\": \"Math Library\" },{ \"math.lib/version\": \"1.0\" },{ \"music.lib/author\": \"GRAME\" },{ \"music.lib/copyright\": \"GRAME\" },{ \"music.lib/deprecated\": \"This library is deprecated and is not maintained anymore. It will be removed in August 2017.\" },{ \"music.lib/license\": \"LGPL with exception\" },{ \"music.lib/name\": \"Music Library\" },{ \"music.lib/version\": \"1.0\" },{ \"name\": \"kisana\" }],\"ui\": [ {\"type\": \"vgroup\",\"label\": \"kisana\",\"items\": [ {\"type\": \"hgroup\",\"label\": \"Loops\",\"items\": [ {\"type\": \"vgroup\",\"label\": \"loop\",\"items\": [ {\"type\": \"vslider\",\"label\": \"level\",\"address\": \"/kisana/Loops/loop/level\",\"init\": 0,\"min\": 0,\"max\": 6,\"step\": 1}]},{\"type\": \"vgroup\",\"label\": \"loop48\",\"items\": [ {\"type\": \"vslider\",\"label\": \"note\",\"address\": \"/kisana/Loops/loop48/note\",\"meta\": [{ \"1\": \"\" }],\"init\": 0,\"min\": 0,\"max\": 11,\"step\": 1}]},{\"type\": \"vgroup\",\"label\": \"loop60\",\"items\": [ {\"type\": \"vslider\",\"label\": \"note\",\"address\": \"/kisana/Loops/loop60/note\",\"meta\": [{ \"1\": \"\" }],\"init\": 0,\"min\": 0,\"max\": 11,\"step\": 1}]},{\"type\": \"vgroup\",\"label\": \"loop72\",\"items\": [ {\"type\": \"vslider\",\"label\": \"note\",\"address\": \"/kisana/Loops/loop72/note\",\"meta\": [{ \"1\": \"\" }],\"init\": 0,\"min\": 0,\"max\": 11,\"step\": 1}]}]},{\"type\": \"hslider\",\"label\": \"master\",\"address\": \"/kisana/master\",\"meta\": [{ \"1\": \"\" }],\"init\": -20,\"min\": -60,\"max\": 0,\"step\": 0.01},{\"type\": \"hslider\",\"label\": \"timbre\",\"address\": \"/kisana/timbre\",\"meta\": [{ \"2\": \"\" }],\"init\": 0,\"min\": 0,\"max\": 1,\"step\": 0.01}]}]}"
end

function buildUserInterface!(dsp::mydsp{T}, ui_interface::UI) where {T}
	openVerticalBox!(ui_interface, "kisana") 
	openHorizontalBox!(ui_interface, "Loops") 
	openVerticalBox!(ui_interface, "loop") 
	addVerticalSlider!(ui_interface, "level", :fVslider1, FAUSTFLOAT(0.0f0), FAUSTFLOAT(0.0f0), FAUSTFLOAT(6.0f0), FAUSTFLOAT(1.0f0)) 
	closeBox!(ui_interface)
	openVerticalBox!(ui_interface, "loop48") 
	declare!(ui_interface, :fVslider0, "1", "") 
	addVerticalSlider!(ui_interface, "note", :fVslider0, FAUSTFLOAT(0.0f0), FAUSTFLOAT(0.0f0), FAUSTFLOAT(11.0f0), FAUSTFLOAT(1.0f0)) 
	closeBox!(ui_interface)
	openVerticalBox!(ui_interface, "loop60") 
	declare!(ui_interface, :fVslider2, "1", "") 
	addVerticalSlider!(ui_interface, "note", :fVslider2, FAUSTFLOAT(0.0f0), FAUSTFLOAT(0.0f0), FAUSTFLOAT(11.0f0), FAUSTFLOAT(1.0f0)) 
	closeBox!(ui_interface)
	openVerticalBox!(ui_interface, "loop72") 
	declare!(ui_interface, :fVslider3, "1", "") 
	addVerticalSlider!(ui_interface, "note", :fVslider3, FAUSTFLOAT(0.0f0), FAUSTFLOAT(0.0f0), FAUSTFLOAT(11.0f0), FAUSTFLOAT(1.0f0)) 
	closeBox!(ui_interface)
	closeBox!(ui_interface)
	declare!(ui_interface, :fHslider0, "1", "") 
	addHorizontalSlider!(ui_interface, "master", :fHslider0, FAUSTFLOAT(-20.0f0), FAUSTFLOAT(-60.0f0), FAUSTFLOAT(0.0f0), FAUSTFLOAT(0.01f0)) 
	declare!(ui_interface, :fHslider1, "2", "") 
	addHorizontalSlider!(ui_interface, "timbre", :fHslider1, FAUSTFLOAT(0.0f0), FAUSTFLOAT(0.0f0), FAUSTFLOAT(1.0f0), FAUSTFLOAT(0.01f0)) 
	closeBox!(ui_interface)
end

@inbounds function compute!(dsp::mydsp{T}, count::Int32, inputs::Matrix{FAUSTFLOAT}, outputs::Matrix{FAUSTFLOAT}) where {T}
	output0 = @inbounds @view outputs[:, 1]
	output1 = @inbounds @view outputs[:, 2]
	fSlow0::T = pow(10.0f0, (0.0500000007f0 * T(dsp.fHslider0))) 
	fSlow1::T = T(dsp.fHslider1) 
	iSlow2::Int32 = (fSlow1 <= 0.0f0) 
	iSlow3::Int32 = trunc(Int32, T(dsp.fVslider0)) 
	iSlow4::Int32 = (T(iSlow3) <= 0.0f0) 
	iSlow5::Int32 = trunc(Int32, T(dsp.fVslider1)) 
	iSlow6::Int32 = (T(iSlow5) <= 0.0f0) 
	iSlow7::Int32 = trunc(Int32, T(dsp.fVslider2)) 
	iSlow8::Int32 = (T(iSlow7) <= 0.0f0) 
	iSlow9::Int32 = trunc(Int32, T(dsp.fVslider3)) 
	iSlow10::Int32 = (T(iSlow9) <= 0.0f0) 
	@inbounds for i0 in 0:count-1
		dsp.fVec0[1] = fSlow1 
		dsp.iRec1[1] = ((dsp.iRec1[2] + Int32(1)) % dsp.iConst0) 
		iTemp0::Int32 = (dsp.iRec1[1] == Int32(0)) 
		dsp.iVec1[1] = iTemp0 
		iTemp1::Int32 = dsp.iVec1[2] 
		dsp.fRec2[1] = ((iTemp1 != 0) ? 0.0f0 : (dsp.fRec2[2] + abs((fSlow1 - dsp.fVec0[2])))) 
		dsp.iRec3[1] = ((iTemp0 + dsp.iRec3[2]) % Int32(15)) 
		dsp.ftbl0[(((iTemp0 & ((dsp.fRec2[1] > 0.0f0) | iSlow2)) != 0) ? dsp.iRec3[1] : Int32(15))+1] = fSlow1 
		fTemp2::T = dsp.ftbl0[dsp.iRec3[1]+1] 
		fTemp3::T = (fTemp2 + 1.0f0) 
		fTemp4::T = (1.0f0 - fTemp2) 
		dsp.iRec4[1] = ((Int32(1103515245) * dsp.iRec4[2]) + Int32(12345)) 
		fTemp5::T = T(dsp.iRec4[1]) 
		dsp.iVec2[1] = iSlow3 
		dsp.iRec6[1] = ((iTemp1 != 0) ? Int32(0) : (dsp.iRec6[2] + abs((iSlow3 - dsp.iVec2[2])))) 
		dsp.ftbl1[(((iTemp0 & ((dsp.iRec6[1] > Int32(0)) | iSlow4)) != 0) ? dsp.iRec3[1] : Int32(15))+1] = T(iSlow3) 
		fTemp6::T = dsp.ftbl1[dsp.iRec3[1]+1] 
		iTemp7::Int32 = (abs((fTemp6 + -10.0f0)) < 0.5f0) 
		dsp.iVec3[1] = iTemp7 
		dsp.fRec5[1] = ((dsp.fRec5[2] + T((T((iTemp7 - dsp.iVec3[2])) > 0.0f0))) - (0.00997732393f0 * T((dsp.fRec5[2] > 0.0f0)))) 
		dsp.iVec4[1] = iSlow5 
		dsp.iRec7[1] = ((iTemp1 != 0) ? Int32(0) : (dsp.iRec7[2] + abs((iSlow5 - dsp.iVec4[2])))) 
		dsp.ftbl2[(((iTemp0 & ((dsp.iRec7[1] > Int32(0)) | iSlow6)) != 0) ? dsp.iRec3[1] : Int32(15))+1] = T(iSlow5) 
		fTemp8::T = pow(10.0f0, (0.0500000007f0 * (dsp.ftbl2[dsp.iRec3[1]+1] + -6.0f0))) 
		dsp.fVec5[(dsp.IOTA & Int32(127))+1] = ((0.498041421f0 * ((fTemp3 * dsp.fRec0[2]) + (fTemp4 * dsp.fRec0[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec5[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec0[1] = dsp.fVec5[((dsp.IOTA - Int32(99)) & Int32(127))+1] 
		dsp.iVec6[1] = iSlow7 
		dsp.iRec10[1] = ((iTemp1 != 0) ? Int32(0) : (dsp.iRec10[2] + abs((iSlow7 - dsp.iVec6[2])))) 
		dsp.ftbl3[(((iTemp0 & ((dsp.iRec10[1] > Int32(0)) | iSlow8)) != 0) ? dsp.iRec3[1] : Int32(15))+1] = T(iSlow7) 
		fTemp9::T = dsp.ftbl3[dsp.iRec3[1]+1] 
		iTemp10::Int32 = (abs((fTemp9 + -10.0f0)) < 0.5f0) 
		dsp.iVec7[1] = iTemp10 
		dsp.fRec9[1] = ((dsp.fRec9[2] + T((T((iTemp10 - dsp.iVec7[2])) > 0.0f0))) - (0.0199546479f0 * T((dsp.fRec9[2] > 0.0f0)))) 
		dsp.fVec8[(dsp.IOTA & Int32(63))+1] = ((0.499019742f0 * ((fTemp3 * dsp.fRec8[2]) + (fTemp4 * dsp.fRec8[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec9[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec8[1] = dsp.fVec8[((dsp.IOTA - Int32(49)) & Int32(63))+1] 
		fTemp11::T = (dsp.fRec0[1] + dsp.fRec8[1]) 
		iTemp12::Int32 = (abs((fTemp6 + -9.0f0)) < 0.5f0) 
		dsp.iVec9[1] = iTemp12 
		dsp.fRec12[1] = ((dsp.fRec12[2] + T((T((iTemp12 - dsp.iVec9[2])) > 0.0f0))) - (0.00888878573f0 * T((dsp.fRec12[2] > 0.0f0)))) 
		dsp.fVec10[(dsp.IOTA & Int32(127))+1] = ((0.497802079f0 * ((fTemp3 * dsp.fRec11[2]) + (fTemp4 * dsp.fRec11[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec12[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec11[1] = dsp.fVec10[((dsp.IOTA - Int32(111)) & Int32(127))+1] 
		iTemp13::Int32 = (abs((fTemp9 + -9.0f0)) < 0.5f0) 
		dsp.iVec11[1] = iTemp13 
		dsp.fRec14[1] = ((dsp.fRec14[2] + T((T((iTemp13 - dsp.iVec11[2])) > 0.0f0))) - (0.0177775715f0 * T((dsp.fRec14[2] > 0.0f0)))) 
		dsp.fVec12[(dsp.IOTA & Int32(63))+1] = ((0.498899847f0 * ((fTemp3 * dsp.fRec13[2]) + (fTemp4 * dsp.fRec13[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec14[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec13[1] = dsp.fVec12[((dsp.IOTA - Int32(55)) & Int32(63))+1] 
		fTemp14::T = (dsp.fRec11[1] + dsp.fRec13[1]) 
		iTemp15::Int32 = (abs((fTemp6 + -8.0f0)) < 0.5f0) 
		dsp.iVec13[1] = iTemp15 
		dsp.fRec16[1] = ((dsp.fRec16[2] + T((T((iTemp15 - dsp.iVec13[2])) > 0.0f0))) - (0.00747454772f0 * T((dsp.fRec16[2] > 0.0f0)))) 
		dsp.fVec14[(dsp.IOTA & Int32(255))+1] = ((0.49738732f0 * ((fTemp3 * dsp.fRec15[2]) + (fTemp4 * dsp.fRec15[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec16[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec15[1] = dsp.fVec14[((dsp.IOTA - Int32(132)) & Int32(255))+1] 
		iTemp16::Int32 = (abs((fTemp9 + -8.0f0)) < 0.5f0) 
		dsp.iVec15[1] = iTemp16 
		dsp.fRec18[1] = ((dsp.fRec18[2] + T((T((iTemp16 - dsp.iVec15[2])) > 0.0f0))) - (0.0149490954f0 * T((dsp.fRec18[2] > 0.0f0)))) 
		dsp.fVec16[(dsp.IOTA & Int32(127))+1] = ((0.498691946f0 * ((fTemp3 * dsp.fRec17[2]) + (fTemp4 * dsp.fRec17[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec18[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec17[1] = dsp.fVec16[((dsp.IOTA - Int32(65)) & Int32(127))+1] 
		fTemp17::T = (dsp.fRec15[1] + dsp.fRec17[1]) 
		iTemp18::Int32 = (abs((fTemp6 + -7.0f0)) < 0.5f0) 
		dsp.iVec17[1] = iTemp18 
		dsp.fRec20[1] = ((dsp.fRec20[2] + T((T((iTemp18 - dsp.iVec17[2])) > 0.0f0))) - (0.00665906491f0 * T((dsp.fRec20[2] > 0.0f0)))) 
		dsp.fVec18[(dsp.IOTA & Int32(255))+1] = ((0.497068316f0 * ((fTemp3 * dsp.fRec19[2]) + (fTemp4 * dsp.fRec19[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec20[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec19[1] = dsp.fVec18[((dsp.IOTA - Int32(149)) & Int32(255))+1] 
		iTemp19::Int32 = (abs((fTemp9 + -7.0f0)) < 0.5f0) 
		dsp.iVec19[1] = iTemp19 
		dsp.fRec22[1] = ((dsp.fRec22[2] + T((T((iTemp19 - dsp.iVec19[2])) > 0.0f0))) - (0.0133181298f0 * T((dsp.fRec22[2] > 0.0f0)))) 
		dsp.fVec20[(dsp.IOTA & Int32(127))+1] = ((0.498531997f0 * ((fTemp3 * dsp.fRec21[2]) + (fTemp4 * dsp.fRec21[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec22[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec21[1] = dsp.fVec20[((dsp.IOTA - Int32(74)) & Int32(127))+1] 
		fTemp20::T = (dsp.fRec19[1] + dsp.fRec21[1]) 
		iTemp21::Int32 = (abs((fTemp6 + -6.0f0)) < 0.5f0) 
		dsp.iVec21[1] = iTemp21 
		dsp.fRec24[1] = ((dsp.fRec24[2] + T((T((iTemp21 - dsp.iVec21[2])) > 0.0f0))) - (0.00593255227f0 * T((dsp.fRec24[2] > 0.0f0)))) 
		dsp.fVec22[(dsp.IOTA & Int32(255))+1] = ((0.496710479f0 * ((fTemp3 * dsp.fRec23[2]) + (fTemp4 * dsp.fRec23[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec24[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec23[1] = dsp.fVec22[((dsp.IOTA - Int32(167)) & Int32(255))+1] 
		iTemp22::Int32 = (abs((fTemp9 + -6.0f0)) < 0.5f0) 
		dsp.iVec23[1] = iTemp22 
		dsp.fRec26[1] = ((dsp.fRec26[2] + T((T((iTemp22 - dsp.iVec23[2])) > 0.0f0))) - (0.0118651045f0 * T((dsp.fRec26[2] > 0.0f0)))) 
		dsp.fVec24[(dsp.IOTA & Int32(127))+1] = ((0.498352528f0 * ((fTemp3 * dsp.fRec25[2]) + (fTemp4 * dsp.fRec25[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec26[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec25[1] = dsp.fVec24[((dsp.IOTA - Int32(83)) & Int32(127))+1] 
		fTemp23::T = (0.707106769f0 * (dsp.fRec23[1] + dsp.fRec25[1])) 
		iTemp24::Int32 = (abs((fTemp6 + -5.0f0)) < 0.5f0) 
		dsp.iVec25[1] = iTemp24 
		dsp.fRec28[1] = ((dsp.fRec28[2] + T((T((iTemp24 - dsp.iVec25[2])) > 0.0f0))) - (0.00498866197f0 * T((dsp.fRec28[2] > 0.0f0)))) 
		dsp.fVec26[(dsp.IOTA & Int32(255))+1] = ((0.496090502f0 * ((fTemp3 * dsp.fRec27[2]) + (fTemp4 * dsp.fRec27[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec28[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec27[1] = dsp.fVec26[((dsp.IOTA - Int32(199)) & Int32(255))+1] 
		iTemp25::Int32 = (abs((fTemp9 + -5.0f0)) < 0.5f0) 
		dsp.iVec27[1] = iTemp25 
		dsp.fRec30[1] = ((dsp.fRec30[2] + T((T((iTemp25 - dsp.iVec27[2])) > 0.0f0))) - (0.00997732393f0 * T((dsp.fRec30[2] > 0.0f0)))) 
		dsp.fVec28[(dsp.IOTA & Int32(127))+1] = ((0.498041421f0 * ((fTemp3 * dsp.fRec29[2]) + (fTemp4 * dsp.fRec29[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec30[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec29[1] = dsp.fVec28[((dsp.IOTA - Int32(99)) & Int32(127))+1] 
		fTemp26::T = (dsp.fRec27[1] + dsp.fRec29[1]) 
		iTemp27::Int32 = (abs((fTemp6 + -4.0f0)) < 0.5f0) 
		dsp.iVec29[1] = iTemp27 
		dsp.fRec32[1] = ((dsp.fRec32[2] + T((T((iTemp27 - dsp.iVec29[2])) > 0.0f0))) - (0.00444439286f0 * T((dsp.fRec32[2] > 0.0f0)))) 
		dsp.fVec30[(dsp.IOTA & Int32(255))+1] = ((0.495613843f0 * ((fTemp3 * dsp.fRec31[2]) + (fTemp4 * dsp.fRec31[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec32[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec31[1] = dsp.fVec30[((dsp.IOTA - Int32(224)) & Int32(255))+1] 
		iTemp28::Int32 = (abs((fTemp9 + -4.0f0)) < 0.5f0) 
		dsp.iVec31[1] = iTemp28 
		dsp.fRec34[1] = ((dsp.fRec34[2] + T((T((iTemp28 - dsp.iVec31[2])) > 0.0f0))) - (0.00888878573f0 * T((dsp.fRec34[2] > 0.0f0)))) 
		dsp.fVec32[(dsp.IOTA & Int32(127))+1] = ((0.497802079f0 * ((fTemp3 * dsp.fRec33[2]) + (fTemp4 * dsp.fRec33[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec34[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec33[1] = dsp.fVec32[((dsp.IOTA - Int32(111)) & Int32(127))+1] 
		fTemp29::T = (dsp.fRec31[1] + dsp.fRec33[1]) 
		iTemp30::Int32 = (abs((fTemp6 + -3.0f0)) < 0.5f0) 
		dsp.iVec33[1] = iTemp30 
		dsp.fRec36[1] = ((dsp.fRec36[2] + T((T((iTemp30 - dsp.iVec33[2])) > 0.0f0))) - (0.00373727386f0 * T((dsp.fRec36[2] > 0.0f0)))) 
		dsp.fVec34[(dsp.IOTA & Int32(511))+1] = ((0.494788289f0 * ((fTemp3 * dsp.fRec35[2]) + (fTemp4 * dsp.fRec35[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec36[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec35[1] = dsp.fVec34[((dsp.IOTA - Int32(266)) & Int32(511))+1] 
		iTemp31::Int32 = (abs((fTemp9 + -3.0f0)) < 0.5f0) 
		dsp.iVec35[1] = iTemp31 
		dsp.fRec38[1] = ((dsp.fRec38[2] + T((T((iTemp31 - dsp.iVec35[2])) > 0.0f0))) - (0.00747454772f0 * T((dsp.fRec38[2] > 0.0f0)))) 
		dsp.fVec36[(dsp.IOTA & Int32(255))+1] = ((0.49738732f0 * ((fTemp3 * dsp.fRec37[2]) + (fTemp4 * dsp.fRec37[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec38[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec37[1] = dsp.fVec36[((dsp.IOTA - Int32(132)) & Int32(255))+1] 
		fTemp32::T = (dsp.fRec35[1] + dsp.fRec37[1]) 
		iTemp33::Int32 = (abs((fTemp6 + -2.0f0)) < 0.5f0) 
		dsp.iVec37[1] = iTemp33 
		dsp.fRec40[1] = ((dsp.fRec40[2] + T((T((iTemp33 - dsp.iVec37[2])) > 0.0f0))) - (0.00332953245f0 * T((dsp.fRec40[2] > 0.0f0)))) 
		dsp.fVec38[(dsp.IOTA & Int32(511))+1] = ((0.494153798f0 * ((fTemp3 * dsp.fRec39[2]) + (fTemp4 * dsp.fRec39[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec40[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec39[1] = dsp.fVec38[((dsp.IOTA - Int32(299)) & Int32(511))+1] 
		iTemp34::Int32 = (abs((fTemp9 + -2.0f0)) < 0.5f0) 
		dsp.iVec39[1] = iTemp34 
		dsp.fRec42[1] = ((dsp.fRec42[2] + T((T((iTemp34 - dsp.iVec39[2])) > 0.0f0))) - (0.00665906491f0 * T((dsp.fRec42[2] > 0.0f0)))) 
		dsp.fVec40[(dsp.IOTA & Int32(255))+1] = ((0.497068316f0 * ((fTemp3 * dsp.fRec41[2]) + (fTemp4 * dsp.fRec41[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec42[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec41[1] = dsp.fVec40[((dsp.IOTA - Int32(149)) & Int32(255))+1] 
		fTemp35::T = (dsp.fRec39[1] + dsp.fRec41[1]) 
		iTemp36::Int32 = (abs((fTemp6 + -1.0f0)) < 0.5f0) 
		dsp.iVec41[1] = iTemp36 
		dsp.fRec44[1] = ((dsp.fRec44[2] + T((T((iTemp36 - dsp.iVec41[2])) > 0.0f0))) - (0.00296627614f0 * T((dsp.fRec44[2] > 0.0f0)))) 
		dsp.fVec42[(dsp.IOTA & Int32(511))+1] = ((0.493442565f0 * ((dsp.fRec43[2] * fTemp3) + (fTemp4 * dsp.fRec43[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec44[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec43[1] = dsp.fVec42[((dsp.IOTA - Int32(336)) & Int32(511))+1] 
		iTemp37::Int32 = (abs((fTemp9 + -1.0f0)) < 0.5f0) 
		dsp.iVec43[1] = iTemp37 
		dsp.fRec46[1] = ((dsp.fRec46[2] + T((T((iTemp37 - dsp.iVec43[2])) > 0.0f0))) - (0.00593255227f0 * T((dsp.fRec46[2] > 0.0f0)))) 
		dsp.fVec44[(dsp.IOTA & Int32(255))+1] = ((0.496710479f0 * ((fTemp3 * dsp.fRec45[2]) + (fTemp4 * dsp.fRec45[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec46[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec45[1] = dsp.fVec44[((dsp.IOTA - Int32(167)) & Int32(255))+1] 
		fTemp38::T = (dsp.fRec43[1] + dsp.fRec45[1]) 
		iTemp39::Int32 = (abs((fTemp6 + -11.0f0)) < 0.5f0) 
		dsp.iVec45[1] = iTemp39 
		dsp.fRec48[1] = ((dsp.fRec48[2] + T((T((iTemp39 - dsp.iVec45[2])) > 0.0f0))) - (0.0118651045f0 * T((dsp.fRec48[2] > 0.0f0)))) 
		dsp.fVec46[(dsp.IOTA & Int32(127))+1] = ((0.498352528f0 * ((fTemp3 * dsp.fRec47[2]) + (fTemp4 * dsp.fRec47[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec48[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec47[1] = dsp.fVec46[((dsp.IOTA - Int32(83)) & Int32(127))+1] 
		iTemp40::Int32 = (abs((fTemp9 + -11.0f0)) < 0.5f0) 
		dsp.iVec47[1] = iTemp40 
		dsp.fRec50[1] = ((dsp.fRec50[2] + T((T((iTemp40 - dsp.iVec47[2])) > 0.0f0))) - (0.0237302091f0 * T((dsp.fRec50[2] > 0.0f0)))) 
		dsp.fVec48[(dsp.IOTA & Int32(63))+1] = ((0.499175578f0 * ((fTemp3 * dsp.fRec49[2]) + (fTemp4 * dsp.fRec49[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec50[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec49[1] = dsp.fVec48[((dsp.IOTA - Int32(41)) & Int32(63))+1] 
		fTemp41::T = (dsp.fRec47[1] + dsp.fRec49[1]) 
		dsp.iVec49[1] = iSlow9 
		dsp.iRec53[1] = ((iTemp1 != 0) ? Int32(0) : (dsp.iRec53[2] + abs((iSlow9 - dsp.iVec49[2])))) 
		dsp.ftbl4[(((iTemp0 & ((dsp.iRec53[1] > Int32(0)) | iSlow10)) != 0) ? dsp.iRec3[1] : Int32(15))+1] = T(iSlow9) 
		fTemp42::T = dsp.ftbl4[dsp.iRec3[1]+1] 
		iTemp43::Int32 = (abs((fTemp42 + -1.0f0)) < 0.5f0) 
		dsp.iVec50[1] = iTemp43 
		dsp.fRec52[1] = ((dsp.fRec52[2] + T((T((iTemp43 - dsp.iVec50[2])) > 0.0f0))) - (0.0118651045f0 * T((dsp.fRec52[2] > 0.0f0)))) 
		dsp.fVec51[(dsp.IOTA & Int32(127))+1] = ((0.498352528f0 * ((fTemp3 * dsp.fRec51[2]) + (fTemp4 * dsp.fRec51[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec52[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec51[1] = dsp.fVec51[((dsp.IOTA - Int32(83)) & Int32(127))+1] 
		iTemp44::Int32 = (abs((fTemp42 + -2.0f0)) < 0.5f0) 
		dsp.iVec52[1] = iTemp44 
		dsp.fRec55[1] = ((dsp.fRec55[2] + T((T((iTemp44 - dsp.iVec52[2])) > 0.0f0))) - (0.0133181298f0 * T((dsp.fRec55[2] > 0.0f0)))) 
		dsp.fVec53[(dsp.IOTA & Int32(127))+1] = ((0.498531997f0 * ((fTemp3 * dsp.fRec54[2]) + (fTemp4 * dsp.fRec54[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec55[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec54[1] = dsp.fVec53[((dsp.IOTA - Int32(74)) & Int32(127))+1] 
		iTemp45::Int32 = (abs((fTemp42 + -3.0f0)) < 0.5f0) 
		dsp.iVec54[1] = iTemp45 
		dsp.fRec57[1] = ((dsp.fRec57[2] + T((T((iTemp45 - dsp.iVec54[2])) > 0.0f0))) - (0.0149490954f0 * T((dsp.fRec57[2] > 0.0f0)))) 
		dsp.fVec55[(dsp.IOTA & Int32(127))+1] = ((0.498691946f0 * ((fTemp3 * dsp.fRec56[2]) + (fTemp4 * dsp.fRec56[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec57[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec56[1] = dsp.fVec55[((dsp.IOTA - Int32(65)) & Int32(127))+1] 
		iTemp46::Int32 = (abs((fTemp42 + -4.0f0)) < 0.5f0) 
		dsp.iVec56[1] = iTemp46 
		dsp.fRec59[1] = ((dsp.fRec59[2] + T((T((iTemp46 - dsp.iVec56[2])) > 0.0f0))) - (0.0177775715f0 * T((dsp.fRec59[2] > 0.0f0)))) 
		dsp.fVec57[(dsp.IOTA & Int32(63))+1] = ((0.498899847f0 * ((fTemp3 * dsp.fRec58[2]) + (fTemp4 * dsp.fRec58[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec59[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec58[1] = dsp.fVec57[((dsp.IOTA - Int32(55)) & Int32(63))+1] 
		iTemp47::Int32 = (abs((fTemp42 + -5.0f0)) < 0.5f0) 
		dsp.iVec58[1] = iTemp47 
		dsp.fRec61[1] = ((dsp.fRec61[2] + T((T((iTemp47 - dsp.iVec58[2])) > 0.0f0))) - (0.0199546479f0 * T((dsp.fRec61[2] > 0.0f0)))) 
		dsp.fVec59[(dsp.IOTA & Int32(63))+1] = ((0.499019742f0 * ((fTemp3 * dsp.fRec60[2]) + (fTemp4 * dsp.fRec60[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec61[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec60[1] = dsp.fVec59[((dsp.IOTA - Int32(49)) & Int32(63))+1] 
		iTemp48::Int32 = (abs((fTemp42 + -6.0f0)) < 0.5f0) 
		dsp.iVec60[1] = iTemp48 
		dsp.fRec63[1] = ((dsp.fRec63[2] + T((T((iTemp48 - dsp.iVec60[2])) > 0.0f0))) - (0.0237302091f0 * T((dsp.fRec63[2] > 0.0f0)))) 
		dsp.fVec61[(dsp.IOTA & Int32(63))+1] = ((0.499175578f0 * ((fTemp3 * dsp.fRec62[2]) + (fTemp4 * dsp.fRec62[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec63[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec62[1] = dsp.fVec61[((dsp.IOTA - Int32(41)) & Int32(63))+1] 
		fTemp49::T = (0.707106769f0 * dsp.fRec62[1]) 
		iTemp50::Int32 = (abs((fTemp42 + -7.0f0)) < 0.5f0) 
		dsp.iVec62[1] = iTemp50 
		dsp.fRec65[1] = ((dsp.fRec65[2] + T((T((iTemp50 - dsp.iVec62[2])) > 0.0f0))) - (0.0266362596f0 * T((dsp.fRec65[2] > 0.0f0)))) 
		dsp.fVec63[(dsp.IOTA & Int32(63))+1] = ((0.499265462f0 * ((fTemp3 * dsp.fRec64[2]) + (fTemp4 * dsp.fRec64[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec65[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec64[1] = dsp.fVec63[((dsp.IOTA - Int32(36)) & Int32(63))+1] 
		iTemp51::Int32 = (abs((fTemp42 + -8.0f0)) < 0.5f0) 
		dsp.iVec64[1] = iTemp51 
		dsp.fRec67[1] = ((dsp.fRec67[2] + T((T((iTemp51 - dsp.iVec64[2])) > 0.0f0))) - (0.0298981909f0 * T((dsp.fRec67[2] > 0.0f0)))) 
		dsp.fVec65[(dsp.IOTA & Int32(63))+1] = ((0.499345541f0 * ((fTemp3 * dsp.fRec66[2]) + (fTemp4 * dsp.fRec66[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec67[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec66[1] = dsp.fVec65[((dsp.IOTA - Int32(32)) & Int32(63))+1] 
		iTemp52::Int32 = (abs((fTemp42 + -9.0f0)) < 0.5f0) 
		dsp.iVec66[1] = iTemp52 
		dsp.fRec69[1] = ((dsp.fRec69[2] + T((T((iTemp52 - dsp.iVec66[2])) > 0.0f0))) - (0.0355551429f0 * T((dsp.fRec69[2] > 0.0f0)))) 
		dsp.fVec67[(dsp.IOTA & Int32(31))+1] = ((0.499449611f0 * ((fTemp3 * dsp.fRec68[2]) + (fTemp4 * dsp.fRec68[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec69[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec68[1] = dsp.fVec67[((dsp.IOTA - Int32(27)) & Int32(31))+1] 
		iTemp53::Int32 = (abs((fTemp42 + -10.0f0)) < 0.5f0) 
		dsp.iVec68[1] = iTemp53 
		dsp.fRec71[1] = ((dsp.fRec71[2] + T((T((iTemp53 - dsp.iVec68[2])) > 0.0f0))) - (0.0399092957f0 * T((dsp.fRec71[2] > 0.0f0)))) 
		dsp.fVec69[(dsp.IOTA & Int32(31))+1] = ((0.499509633f0 * ((fTemp3 * dsp.fRec70[2]) + (fTemp4 * dsp.fRec70[3]))) + (4.65661287f-10 * ((fTemp5 * T((dsp.fRec71[1] > 0.0f0))) * fTemp8))) 
		dsp.fRec70[1] = dsp.fVec69[((dsp.IOTA - Int32(24)) & Int32(31))+1] 
		iTemp54::Int32 = (abs((fTemp42 + -11.0f0)) < 0.5f0) 
		dsp.iVec70[1] = iTemp54 
		dsp.fRec73[1] = ((dsp.fRec73[2] + T((T((iTemp54 - dsp.iVec70[2])) > 0.0f0))) - (0.0474604182f0 * T((dsp.fRec73[2] > 0.0f0)))) 
		dsp.fVec71[(dsp.IOTA & Int32(31))+1] = ((0.499587625f0 * ((fTemp3 * dsp.fRec72[2]) + (fTemp4 * dsp.fRec72[3]))) + (4.65661287f-10 * ((T((dsp.fRec73[1] > 0.0f0)) * fTemp5) * fTemp8))) 
		dsp.fRec72[1] = dsp.fVec71[((dsp.IOTA - Int32(20)) & Int32(31))+1] 
		output0[i0+1] = FAUSTFLOAT((fSlow0 * (((0.369274467f0 * fTemp11) + ((0.4767313f0 * fTemp14) + ((0.564076066f0 * fTemp17) + ((0.639602125f0 * fTemp20) + (fTemp23 + ((0.768706143f0 * fTemp26) + ((0.825722814f0 * fTemp29) + ((0.879049063f0 * fTemp32) + ((0.929320395f0 * fTemp35) + ((0.977008402f0 * fTemp38) + (0.213200718f0 * fTemp41))))))))))) + (1.5f0 * (((((((((((0.977008402f0 * dsp.fRec51[1]) + (0.929320395f0 * dsp.fRec54[1])) + (0.879049063f0 * dsp.fRec56[1])) + (0.825722814f0 * dsp.fRec58[1])) + (0.768706143f0 * dsp.fRec60[1])) + fTemp49) + (0.639602125f0 * dsp.fRec64[1])) + (0.564076066f0 * dsp.fRec66[1])) + (0.4767313f0 * dsp.fRec68[1])) + (0.369274467f0 * dsp.fRec70[1])) + (0.213200718f0 * dsp.fRec72[1])))))) 
		output1[i0+1] = FAUSTFLOAT((fSlow0 * (((0.929320395f0 * fTemp11) + ((0.879049063f0 * fTemp14) + ((0.825722814f0 * fTemp17) + ((0.768706143f0 * fTemp20) + (fTemp23 + ((0.639602125f0 * fTemp26) + ((0.564076066f0 * fTemp29) + ((0.4767313f0 * fTemp32) + ((0.369274467f0 * fTemp35) + ((0.213200718f0 * fTemp38) + (0.977008402f0 * fTemp41))))))))))) + (1.5f0 * ((((((fTemp49 + (((((0.213200718f0 * dsp.fRec51[1]) + (0.369274467f0 * dsp.fRec54[1])) + (0.4767313f0 * dsp.fRec56[1])) + (0.564076066f0 * dsp.fRec58[1])) + (0.639602125f0 * dsp.fRec60[1]))) + (0.768706143f0 * dsp.fRec64[1])) + (0.825722814f0 * dsp.fRec66[1])) + (0.879049063f0 * dsp.fRec68[1])) + (0.929320395f0 * dsp.fRec70[1])) + (0.977008402f0 * dsp.fRec72[1])))))) 
		dsp.fVec0[2] = dsp.fVec0[1] 
		dsp.iRec1[2] = dsp.iRec1[1] 
		dsp.iVec1[2] = dsp.iVec1[1] 
		dsp.fRec2[2] = dsp.fRec2[1] 
		dsp.iRec3[2] = dsp.iRec3[1] 
		dsp.iRec4[2] = dsp.iRec4[1] 
		dsp.iVec2[2] = dsp.iVec2[1] 
		dsp.iRec6[2] = dsp.iRec6[1] 
		dsp.iVec3[2] = dsp.iVec3[1] 
		dsp.fRec5[2] = dsp.fRec5[1] 
		dsp.iVec4[2] = dsp.iVec4[1] 
		dsp.iRec7[2] = dsp.iRec7[1] 
		dsp.IOTA = (dsp.IOTA + Int32(1)) 
		dsp.fRec0[3] = dsp.fRec0[2] 
		dsp.fRec0[2] = dsp.fRec0[1] 
		dsp.iVec6[2] = dsp.iVec6[1] 
		dsp.iRec10[2] = dsp.iRec10[1] 
		dsp.iVec7[2] = dsp.iVec7[1] 
		dsp.fRec9[2] = dsp.fRec9[1] 
		dsp.fRec8[3] = dsp.fRec8[2] 
		dsp.fRec8[2] = dsp.fRec8[1] 
		dsp.iVec9[2] = dsp.iVec9[1] 
		dsp.fRec12[2] = dsp.fRec12[1] 
		dsp.fRec11[3] = dsp.fRec11[2] 
		dsp.fRec11[2] = dsp.fRec11[1] 
		dsp.iVec11[2] = dsp.iVec11[1] 
		dsp.fRec14[2] = dsp.fRec14[1] 
		dsp.fRec13[3] = dsp.fRec13[2] 
		dsp.fRec13[2] = dsp.fRec13[1] 
		dsp.iVec13[2] = dsp.iVec13[1] 
		dsp.fRec16[2] = dsp.fRec16[1] 
		dsp.fRec15[3] = dsp.fRec15[2] 
		dsp.fRec15[2] = dsp.fRec15[1] 
		dsp.iVec15[2] = dsp.iVec15[1] 
		dsp.fRec18[2] = dsp.fRec18[1] 
		dsp.fRec17[3] = dsp.fRec17[2] 
		dsp.fRec17[2] = dsp.fRec17[1] 
		dsp.iVec17[2] = dsp.iVec17[1] 
		dsp.fRec20[2] = dsp.fRec20[1] 
		dsp.fRec19[3] = dsp.fRec19[2] 
		dsp.fRec19[2] = dsp.fRec19[1] 
		dsp.iVec19[2] = dsp.iVec19[1] 
		dsp.fRec22[2] = dsp.fRec22[1] 
		dsp.fRec21[3] = dsp.fRec21[2] 
		dsp.fRec21[2] = dsp.fRec21[1] 
		dsp.iVec21[2] = dsp.iVec21[1] 
		dsp.fRec24[2] = dsp.fRec24[1] 
		dsp.fRec23[3] = dsp.fRec23[2] 
		dsp.fRec23[2] = dsp.fRec23[1] 
		dsp.iVec23[2] = dsp.iVec23[1] 
		dsp.fRec26[2] = dsp.fRec26[1] 
		dsp.fRec25[3] = dsp.fRec25[2] 
		dsp.fRec25[2] = dsp.fRec25[1] 
		dsp.iVec25[2] = dsp.iVec25[1] 
		dsp.fRec28[2] = dsp.fRec28[1] 
		dsp.fRec27[3] = dsp.fRec27[2] 
		dsp.fRec27[2] = dsp.fRec27[1] 
		dsp.iVec27[2] = dsp.iVec27[1] 
		dsp.fRec30[2] = dsp.fRec30[1] 
		dsp.fRec29[3] = dsp.fRec29[2] 
		dsp.fRec29[2] = dsp.fRec29[1] 
		dsp.iVec29[2] = dsp.iVec29[1] 
		dsp.fRec32[2] = dsp.fRec32[1] 
		dsp.fRec31[3] = dsp.fRec31[2] 
		dsp.fRec31[2] = dsp.fRec31[1] 
		dsp.iVec31[2] = dsp.iVec31[1] 
		dsp.fRec34[2] = dsp.fRec34[1] 
		dsp.fRec33[3] = dsp.fRec33[2] 
		dsp.fRec33[2] = dsp.fRec33[1] 
		dsp.iVec33[2] = dsp.iVec33[1] 
		dsp.fRec36[2] = dsp.fRec36[1] 
		dsp.fRec35[3] = dsp.fRec35[2] 
		dsp.fRec35[2] = dsp.fRec35[1] 
		dsp.iVec35[2] = dsp.iVec35[1] 
		dsp.fRec38[2] = dsp.fRec38[1] 
		dsp.fRec37[3] = dsp.fRec37[2] 
		dsp.fRec37[2] = dsp.fRec37[1] 
		dsp.iVec37[2] = dsp.iVec37[1] 
		dsp.fRec40[2] = dsp.fRec40[1] 
		dsp.fRec39[3] = dsp.fRec39[2] 
		dsp.fRec39[2] = dsp.fRec39[1] 
		dsp.iVec39[2] = dsp.iVec39[1] 
		dsp.fRec42[2] = dsp.fRec42[1] 
		dsp.fRec41[3] = dsp.fRec41[2] 
		dsp.fRec41[2] = dsp.fRec41[1] 
		dsp.iVec41[2] = dsp.iVec41[1] 
		dsp.fRec44[2] = dsp.fRec44[1] 
		dsp.fRec43[3] = dsp.fRec43[2] 
		dsp.fRec43[2] = dsp.fRec43[1] 
		dsp.iVec43[2] = dsp.iVec43[1] 
		dsp.fRec46[2] = dsp.fRec46[1] 
		dsp.fRec45[3] = dsp.fRec45[2] 
		dsp.fRec45[2] = dsp.fRec45[1] 
		dsp.iVec45[2] = dsp.iVec45[1] 
		dsp.fRec48[2] = dsp.fRec48[1] 
		dsp.fRec47[3] = dsp.fRec47[2] 
		dsp.fRec47[2] = dsp.fRec47[1] 
		dsp.iVec47[2] = dsp.iVec47[1] 
		dsp.fRec50[2] = dsp.fRec50[1] 
		dsp.fRec49[3] = dsp.fRec49[2] 
		dsp.fRec49[2] = dsp.fRec49[1] 
		dsp.iVec49[2] = dsp.iVec49[1] 
		dsp.iRec53[2] = dsp.iRec53[1] 
		dsp.iVec50[2] = dsp.iVec50[1] 
		dsp.fRec52[2] = dsp.fRec52[1] 
		dsp.fRec51[3] = dsp.fRec51[2] 
		dsp.fRec51[2] = dsp.fRec51[1] 
		dsp.iVec52[2] = dsp.iVec52[1] 
		dsp.fRec55[2] = dsp.fRec55[1] 
		dsp.fRec54[3] = dsp.fRec54[2] 
		dsp.fRec54[2] = dsp.fRec54[1] 
		dsp.iVec54[2] = dsp.iVec54[1] 
		dsp.fRec57[2] = dsp.fRec57[1] 
		dsp.fRec56[3] = dsp.fRec56[2] 
		dsp.fRec56[2] = dsp.fRec56[1] 
		dsp.iVec56[2] = dsp.iVec56[1] 
		dsp.fRec59[2] = dsp.fRec59[1] 
		dsp.fRec58[3] = dsp.fRec58[2] 
		dsp.fRec58[2] = dsp.fRec58[1] 
		dsp.iVec58[2] = dsp.iVec58[1] 
		dsp.fRec61[2] = dsp.fRec61[1] 
		dsp.fRec60[3] = dsp.fRec60[2] 
		dsp.fRec60[2] = dsp.fRec60[1] 
		dsp.iVec60[2] = dsp.iVec60[1] 
		dsp.fRec63[2] = dsp.fRec63[1] 
		dsp.fRec62[3] = dsp.fRec62[2] 
		dsp.fRec62[2] = dsp.fRec62[1] 
		dsp.iVec62[2] = dsp.iVec62[1] 
		dsp.fRec65[2] = dsp.fRec65[1] 
		dsp.fRec64[3] = dsp.fRec64[2] 
		dsp.fRec64[2] = dsp.fRec64[1] 
		dsp.iVec64[2] = dsp.iVec64[1] 
		dsp.fRec67[2] = dsp.fRec67[1] 
		dsp.fRec66[3] = dsp.fRec66[2] 
		dsp.fRec66[2] = dsp.fRec66[1] 
		dsp.iVec66[2] = dsp.iVec66[1] 
		dsp.fRec69[2] = dsp.fRec69[1] 
		dsp.fRec68[3] = dsp.fRec68[2] 
		dsp.fRec68[2] = dsp.fRec68[1] 
		dsp.iVec68[2] = dsp.iVec68[1] 
		dsp.fRec71[2] = dsp.fRec71[1] 
		dsp.fRec70[3] = dsp.fRec70[2] 
		dsp.fRec70[2] = dsp.fRec70[1] 
		dsp.iVec70[2] = dsp.iVec70[1] 
		dsp.fRec73[2] = dsp.fRec73[1] 
		dsp.fRec72[3] = dsp.fRec72[2] 
		dsp.fRec72[2] = dsp.fRec72[1] 
	end
end

# Main code

using ThreadPools

function main!(args)

    # DSP allocation
    my_dsp = mydsp{REAL}()

    # Audio driver allocation and init
    driver = portaudio(16, 44100)
    init!(driver, "dummy", my_dsp)

    println("getNumInputs: ", getNumInputs(my_dsp))
    println("getNumOutputs: ", getNumOutputs(my_dsp), "\n")
    
     # Print all paths
    map_ui = MapUI(my_dsp)
    buildUserInterface!(my_dsp, map_ui)
    println(getZoneMap(map_ui), "\n")

    #= Possibly manually change control values
    - using simple labels (end of path):
    setParamValue!(map_ui, "freq", 500.0f0)
    setParamValue!(map_ui, "volume", -10.0f0)
    - or using complete path:
    setParamValue!(map_ui, "/Oscillator/freq", 500.0f0)
    setParamValue!(map_ui, "/Oscillator/volume", -10.0f0)
    =#

    # No controller
    if length(args) == 0
        run(driver)
    # OSC controller
    elseif startswith(args[1], "-osc")
        ThreadPools.@tspawnat 2 run(driver)
        osc_ui = OSCUI(my_dsp)
        buildUserInterface!(my_dsp, osc_ui)
        if args[1] == "-oscc"
            # Launch external OSC controller
            root = getRoot(osc_ui.map_ui)
            ThreadPools.@tspawnat 2 Base.run(`faust-osc-controller $(root) -port 5001 -outport 5000 -xmit 1`)
        end   
        # Blocking...
        run(osc_ui)
    # GTK controller
    elseif args[1] == "-gtk"
        ThreadPools.@tspawnat 2 run(driver)
        println("Starting with GTK interface")
        gtk_ui = GTKUI(my_dsp)
        buildUserInterface!(my_dsp, gtk_ui)
        # Blocking...
        run(gtk_ui)
    end

end

# Start the application
main!(ARGS)
